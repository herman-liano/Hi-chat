import NextAuth from 'next-auth';
import Credentials from 'next-auth/providers/credentials';
import Google from 'next-auth/providers/google';

const googleEnabled = Boolean(process.env.AUTH_GOOGLE_ID && process.env.AUTH_GOOGLE_SECRET);
export const { handlers, auth, signIn, signOut } = NextAuth({
  trustHost: true,
  secret: process.env.AUTH_SECRET,
  pages: { signIn: '/login' },
  session: { strategy: 'jwt' },
  providers: [
    Credentials({
      name: 'Email and password',
      credentials: { email: { label: 'Email', type: 'email' }, password: { label: 'Password', type: 'password' } },
      async authorize(credentials) {
        const email = String(credentials?.email || '').trim().toLowerCase();
        const password = String(credentials?.password || '');
        if (email === 'hello@hchat.app' && password === 'Demo1234!') return { id: 'demo', name: 'Tadjodong Liano Herman', email, image: '/avatars/herman.jpg' };
        try {
          const res = await fetch(`http://127.0.0.1:${process.env.PORT || 3000}/api/users/verify`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }), cache: 'no-store' });
          if (!res.ok) return null;
          const user = await res.json();
          return { id: user.id, name: user.name, email: user.email, image: '/avatars/herman.jpg' };
        } catch { return null; }
      },
    }),
    ...(googleEnabled ? [Google({ clientId: process.env.AUTH_GOOGLE_ID!, clientSecret: process.env.AUTH_GOOGLE_SECRET! })] : []),
  ],
});
