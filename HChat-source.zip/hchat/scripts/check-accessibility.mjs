// Run while `npm run dev` or `npm start` is running. Install Chromium with `npx playwright install chromium`.
import { chromium } from 'playwright';
import AxeBuilder from '@axe-core/playwright';
const base = process.env.HCHAT_URL || `http://127.0.0.1:${process.env.PORT || 3000}`;
const browser = await chromium.launch({ args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await context.newPage();
let failed = false;
for (const [name, path] of [['Chat · midnight', '/'], ['Authentication', '/login']]) {
  await page.goto(base + path, { waitUntil: 'networkidle' });
  await page.waitForTimeout(850); // Let entrance animations settle before measuring color contrast.
  const result = await new AxeBuilder({ page }).analyze();
  console.log(`${name}: ${result.violations.length} axe violations`);
  for (const issue of result.violations) { failed = true; console.log(`  ${issue.impact}: ${issue.id} (${issue.nodes.length} nodes)`); }
}
await page.goto(base + '/', { waitUntil: 'networkidle' });
await page.locator('.rail-bottom button[aria-label="Settings"]').click();
await page.locator('.settings-navigation button').filter({ hasText: 'Appearance' }).click();
await page.locator('.theme-options button').nth(1).click();
await page.keyboard.press('Escape');
await page.waitForTimeout(450);
const light = await new AxeBuilder({ page }).analyze();
console.log(`Chat · daylight: ${light.violations.length} axe violations`);
for (const issue of light.violations) { failed = true; console.log(`  ${issue.impact}: ${issue.id} (${issue.nodes.length} nodes)`); }
const mobileContext = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
const mobile = await mobileContext.newPage();
await mobile.goto(base + '/', { waitUntil: 'networkidle' });
await mobile.waitForTimeout(400);
let mobileResults = await new AxeBuilder({ page: mobile }).analyze();
console.log(`Mobile · conversations: ${mobileResults.violations.length} axe violations`);
for (const issue of mobileResults.violations) { failed = true; console.log(`  ${issue.impact}: ${issue.id}`); }
await mobile.locator('.conversation-item').first().click();
await mobile.waitForTimeout(500);
mobileResults = await new AxeBuilder({ page: mobile }).analyze();
console.log(`Mobile · chat: ${mobileResults.violations.length} axe violations`);
for (const issue of mobileResults.violations) { failed = true; console.log(`  ${issue.impact}: ${issue.id}`); }
await browser.close();
if (failed) process.exitCode = 1;
