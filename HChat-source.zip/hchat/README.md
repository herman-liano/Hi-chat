# HChat

**Simple. Fast. Intelligent.** A premium messaging product concept designed and built by **Tadjodong Liano Herman**.

HChat is a runnable full-stack product demo: a responsive chat workspace with a distinct SaaS authentication experience, shared media, group conversations, search, reminders, and a built-in AI copilot. It opens directly into a seeded workspace so the design and interactions can be explored without credentials.

## Run it

```bash
npm install
npm run dev
```

Open **http://localhost:3000** for the chat workspace or **http://localhost:3000/login** for authentication. For a real demo session, use **hello@hchat.app** / **Demo1234!**, create a new account, or select **Explore the demo**.

The included `.env.local` contains a **development-only** Auth.js secret so the demo works immediately. Replace `AUTH_SECRET` with a unique secret before any deployment. The server binds to `0.0.0.0` on port `3000` by default; set `PORT` to use another port. API and Socket.IO use the **same origin**, so the app also works behind a preview or reverse proxy without browser-side localhost calls.

```bash
npm run typecheck
# With the dev server running and Chromium installed: npm run test:a11y
npm run build
npm start
```

## What's included

- **Designed chat workspace:** three-column desktop layout, persistent navigation rail, conversation filters, presence, message statuses, timestamp grouping, reactions, image and file attachments, typing events, and responsive mobile chat navigation.
- **Authentication:** Auth.js v5 credential sessions, account creation with bcrypt password hashing, Google OAuth when credentials are supplied, and a 15-minute password-reset flow. During local development, reset links appear in the UI; configured deployments can email them through Resend.
- **Realtime transport:** Express and Socket.IO on the same HTTP server, with conversation rooms, message events, typing events, reaction updates, and reminder events.
- **Search:** instant highlighted results across people, messages, files, and links; open with the sidebar search or `⌘K` / `Ctrl+K`.
- **Assistant:** conversation summaries, contextual suggested replies, translation, and reminders. A working preview fallback is provided without an AI key; add `OPENAI_API_KEY` for open-ended generation and translation.
- **Groups:** new-group creation, members, Owner/Admin/Member roles in the UI, management controls, polls with voting, and announcement messages.
- **Profiles and settings:** profile views, bio, mutual groups, shared media gallery, security, appearance (midnight/daylight and accent colors), notifications, privacy preferences, and language preference.
- **Accessibility:** keyboard navigation, dialog focus trapping and Escape handling, labels and visible focus states, reduced-motion support, and automated axe checks with no violations on the principal dark/light and login screens.

The demo avatar photography is sourced from Unsplash. The brand and media artwork in `public/media` are original SVG assets made for this project.

## Architecture

| Layer | Implementation |
| --- | --- |
| UI | Next.js 15, React 19, TypeScript, Tailwind CSS, Framer Motion, Lucide icons |
| API | Node.js and Express (`server/index.mjs`) |
| Realtime | Socket.IO (`/socket.io` on the app origin) |
| Database | PostgreSQL via `pg`, with schema auto-init; local JSON fallback for immediate preview |
| Sessions | Auth.js Credentials and optional Google provider |
| Files | Cloudinary if configured; local uploads in development |
| AI | OpenAI-compatible chat-completions endpoint if configured; deterministic preview responses otherwise |

The custom server prepares Next.js and mounts Express routes and Socket.IO on the **same port**. Frontend requests always use relative URLs. The Next.js dev upgrade handler is registered for hot reload.

### PostgreSQL

```bash
docker compose up -d
# Add DATABASE_URL=postgresql://hchat:hchat@localhost:5432/hchat to .env.local
npm run dev
```

The server creates tables from `database/schema.sql` and seeds conversations on an empty database. Set `PGSSLMODE=require` only when your hosted PostgreSQL service requires TLS. If `DATABASE_URL` is absent, the app creates `server/data/state.json` as a durable local demo store (not intended for shared production traffic).

### External integrations

Copy `.env.example` to `.env.local` and set only the integrations you need:

- `AUTH_SECRET`: long random secret for Auth.js (required for a secure deployment).
- `AUTH_GOOGLE_ID` / `AUTH_GOOGLE_SECRET`: enables Google sign-in. Register the callback URL `https://YOUR_DOMAIN/api/auth/callback/google` at Google. Set `AUTH_URL` to the deployed public URL when configuring OAuth.
- `CLOUDINARY_URL`: enables Cloudinary uploads. Without it, uploads up to 10 MB are saved locally under `public/uploads` and served by Express.
- `OPENAI_API_KEY`: enables open-ended summaries, reply suggestions, and translation. Without it, HChat provides useful seeded summary/reply previews and sample translations; arbitrary text translation tells the user to configure an AI key.
- `RESEND_API_KEY` / `RESET_FROM_EMAIL`: enables emailed password reset links. Without these, reset links are shown **only in development**.

## API overview

- `GET /api/bootstrap` — initial conversations, messages and reminders
- `GET/POST /api/conversations` and `PATCH /api/conversations/:id` — conversation data
- `GET/POST /api/conversations/:id/messages` — messages
- `PATCH /api/messages/:id/reactions` and `PATCH /api/messages/:id/poll` — interactions
- `GET /api/search?q=…` — search index over stored demo content
- `POST /api/ai` — summary, suggest, translate
- `GET/POST /api/reminders` — reminders
- `POST /api/upload` — local or Cloudinary uploads
- `/api/users/*` — registration, verification and reset flows
- `GET /api/health` — server status

## Demo-to-production notes

This is a **polished, functional MVP/demo**, not a claim that a public multi-tenant messaging service is production-hardened. Seeded presence and the post-send seen receipt illustrate the interface. Before exposing it to real users, add per-user access control to every conversation/message API and Socket.IO room; enforce group permissions server-side; introduce API rate limits, file scanning, audit logs, invitation flows, and proper notification delivery; and move uploads to Cloudinary or another durable object store. Demo preference switches are stored on the current device. No end-to-end encryption or live calling is claimed.

---

*HChat — Simple. Fast. Intelligent. Created by Tadjodong Liano Herman.*
