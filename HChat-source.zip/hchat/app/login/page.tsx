import LoginPage from '@/components/login-page';
export default async function Page({ searchParams }: { searchParams: Promise<{ reset?: string; email?: string; recover?: string }> }) {
  const params = await searchParams;
  return <LoginPage initialMode={params.reset ? 'reset' : params.recover ? 'recover' : 'signin'} initialEmail={params.email || ''} initialToken={params.reset || ''} />;
}
