import '@fontsource-variable/dm-sans/index.css';
import '@fontsource-variable/plus-jakarta-sans/index.css';
import './globals.css';
import type { Metadata, Viewport } from 'next';
import { Providers } from '@/components/providers';

export const metadata: Metadata = {
  title: 'HChat — Simple. Fast. Intelligent.',
  description: 'HChat is a thoughtfully designed home for better conversations. Created by Tadjodong Liano Herman.',
  applicationName: 'HChat',
  keywords: ['HChat', 'messaging', 'team chat', 'AI chat', 'Tadjodong Liano Herman'],
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#0B0B0F' };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body><Providers>{children}</Providers></body></html>;
}
