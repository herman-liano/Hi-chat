import fs from 'node:fs';
import path from 'node:path';
import { Pool } from 'pg';

const root = process.cwd();
const seedPath = path.join(root, 'lib/seed.json');
const dataPath = path.join(root, 'server/data/state.json');

export async function createStore() {
  const seed = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
  if (process.env.DATABASE_URL) {
    const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSLMODE === 'require' ? { rejectUnauthorized: false } : undefined });
    await pool.query(fs.readFileSync(path.join(root, 'database/schema.sql'), 'utf8'));
    const count = await pool.query('SELECT count(*)::int AS count FROM conversations');
    if (!count.rows[0].count) {
      for (const item of [...seed.conversations].reverse()) await pool.query('INSERT INTO conversations(id, data) VALUES($1, $2)', [item.id, item]);
      for (const [i, item] of seed.messages.entries()) await pool.query('INSERT INTO messages(id, conversation_id, data, created_at) VALUES($1,$2,$3,$4)', [item.id, item.conversationId, item, new Date(Date.now() - (seed.messages.length - i) * 60000)]);
    }
    console.log('HChat data: PostgreSQL connected');
    return {
      mode: 'postgresql',
      async all() {
        const [cs, ms, rs] = await Promise.all([pool.query('SELECT data FROM conversations ORDER BY updated_at DESC'), pool.query('SELECT data FROM messages ORDER BY created_at ASC'), pool.query('SELECT data FROM reminders ORDER BY created_at DESC')]);
        return { conversations: cs.rows.map(r => r.data), messages: ms.rows.map(r => r.data), reminders: rs.rows.map(r => r.data) };
      },
      async conversation(id) { const r = await pool.query('SELECT data FROM conversations WHERE id=$1', [id]); return r.rows[0]?.data; },
      async addConversation(item) { await pool.query('INSERT INTO conversations(id,data) VALUES($1,$2)', [item.id, item]); return item; },
      async updateConversation(item) { await pool.query("UPDATE conversations SET updated_at=CASE WHEN data->>'lastMessage' IS DISTINCT FROM $2::jsonb->>'lastMessage' THEN now() ELSE updated_at END, data=$2 WHERE id=$1", [item.id, item]); return item; },
      async addMessage(item) { await pool.query('INSERT INTO messages(id,conversation_id,data) VALUES($1,$2,$3)', [item.id, item.conversationId, item]); return item; },
      async updateMessage(item) { await pool.query('UPDATE messages SET data=$2 WHERE id=$1', [item.id, item]); return item; },
      async message(id) { const r = await pool.query('SELECT data FROM messages WHERE id=$1', [id]); return r.rows[0]?.data; },
      async addReminder(item) { await pool.query('INSERT INTO reminders(id,data) VALUES($1,$2)', [item.id, item]); return item; },
      async addUser(item) { await pool.query('INSERT INTO accounts(email,display_name,password_hash) VALUES($1,$2,$3)', [item.email, item.name, item.passwordHash]); },
      async setReset(email, tokenHash, expiresAt) { await pool.query('INSERT INTO password_resets(email,token_hash,expires_at) VALUES($1,$2,$3) ON CONFLICT (email) DO UPDATE SET token_hash=$2,expires_at=$3', [email, tokenHash, expiresAt]); },
      async getReset(email) { const r = await pool.query('SELECT token_hash AS "tokenHash", expires_at AS "expiresAt" FROM password_resets WHERE email=$1', [email]); return r.rows[0]; },
      async useReset(email, passwordHash) { await pool.query('UPDATE accounts SET password_hash=$2 WHERE email=$1', [email, passwordHash]); await pool.query('DELETE FROM password_resets WHERE email=$1', [email]); },
      async user(email) { const r = await pool.query('SELECT email, display_name AS name, password_hash AS "passwordHash" FROM accounts WHERE email=$1', [email]); return r.rows[0]; },
      async close() { await pool.end(); }
    };
  }
  fs.mkdirSync(path.dirname(dataPath), { recursive: true });
  let state;
  try { state = JSON.parse(fs.readFileSync(dataPath, 'utf8')); }
  catch { state = { ...seed, users: [], reminders: [] }; fs.writeFileSync(dataPath, JSON.stringify(state, null, 2)); }
  state.users ??= []; state.reminders ??= []; state.resets ??= {};
  const save = () => fs.writeFileSync(dataPath, JSON.stringify(state, null, 2));
  console.log('HChat data: local JSON store (set DATABASE_URL for PostgreSQL)');
  return {
    mode: 'local',
    async all() { return { conversations: state.conversations, messages: state.messages, reminders: state.reminders }; },
    async conversation(id) { return state.conversations.find(x => x.id === id); },
    async addConversation(item) { state.conversations.unshift(item); save(); return item; },
    async updateConversation(item) { const current = state.conversations.find(x => x.id === item.id); state.conversations = current?.lastMessage !== item.lastMessage ? [item, ...state.conversations.filter(x => x.id !== item.id)] : state.conversations.map(x => x.id === item.id ? item : x); save(); return item; },
    async addMessage(item) { state.messages.push(item); save(); return item; },
    async updateMessage(item) { state.messages = state.messages.map(x => x.id === item.id ? item : x); save(); return item; },
    async message(id) { return state.messages.find(x => x.id === id); },
    async addReminder(item) { state.reminders.unshift(item); save(); return item; },
    async addUser(item) { state.users.push(item); save(); },
    async setReset(email, tokenHash, expiresAt) { state.resets[email] = { tokenHash, expiresAt }; save(); },
    async getReset(email) { return state.resets[email]; },
    async useReset(email, passwordHash) { state.users = state.users.map(x => x.email === email ? { ...x, passwordHash } : x); delete state.resets[email]; save(); },
    async user(email) { return state.users.find(x => x.email === email); },
    async close() { }
  };
}
