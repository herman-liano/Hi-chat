import nextEnv from '@next/env';
const { loadEnvConfig } = nextEnv;
import next from 'next';
import express from 'express';
import { createServer } from 'node:http';
import { Server as SocketServer } from 'socket.io';
import { randomUUID, randomBytes, createHash, timingSafeEqual } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import { v2 as cloudinary } from 'cloudinary';
import { createStore } from './store.mjs';

loadEnvConfig(process.cwd());
const dev = process.env.NODE_ENV !== 'production';
const port = Number(process.env.PORT || 3000);
const hostname = '0.0.0.0';
const nextApp = next({ dev, hostname, port });
const store = await createStore();
await nextApp.prepare();
const handle = nextApp.getRequestHandler();
const api = express();
const httpServer = createServer(api);
const io = new SocketServer(httpServer, { path: '/socket.io', cors: { origin: true, credentials: true } });
api.disable('x-powered-by');
api.use('/uploads', express.static(path.join(process.cwd(), 'public/uploads'), { fallthrough: false, maxAge: '1d' }));
const nextUpgrade = nextApp.getUpgradeHandler();
httpServer.on('upgrade', (req, socket, head) => { if (req.url?.startsWith('/_next/')) void nextUpgrade(req, socket, head); });
api.use(express.json({ limit: '2mb' }));
api.use('/api', (_req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
const fail = (res, error, code = 400) => res.status(code).json({ error });
const timeNow = () => new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }).format(new Date());

api.get('/api/health', async (_req, res) => res.json({ ok: true, data: store.mode, realtime: true }));
api.get('/api/bootstrap', async (_req, res) => res.json(await store.all()));
api.get('/api/conversations', async (_req, res) => res.json((await store.all()).conversations));
api.post('/api/conversations', async (req, res) => {
  const { name, kind = 'direct', avatar = '', members = [] } = req.body || {};
  if (typeof name !== 'string' || !name.trim() || name.length > 90) return fail(res, 'A conversation name is required.');
  const item = { id: randomUUID(), name: name.trim(), kind: kind === 'group' ? 'group' : 'direct', avatar, role: kind === 'group' ? `${members.length + 1} members` : 'New conversation', bio: kind === 'group' ? 'A space to connect and collaborate.' : 'Start a new conversation.', status: kind === 'group' ? `${members.length + 1} members` : 'Offline', online: false, lastMessage: 'Start a conversation', time: 'Now', unread: 0, ...(kind === 'group' ? { members: [{ name: 'Tadjodong Liano Herman', avatar: '/avatars/herman.jpg', role: 'Owner' }, ...members] } : {}) };
  await store.addConversation(item);
  io.emit('conversation:new', item);
  res.status(201).json(item);
});
api.patch('/api/conversations/:id', async (req, res) => {
  const item = await store.conversation(req.params.id);
  if (!item) return fail(res, 'Conversation not found.', 404);
  const update = { ...item };
  if (typeof req.body.name === 'string' && req.body.name.trim() && req.body.name.length <= 90) update.name = req.body.name.trim();
  if (Array.isArray(req.body.members) && update.kind === 'group') { update.members = req.body.members.slice(0, 50); update.role = `${update.members.length} members`; update.status = update.role; }
  if (typeof req.body.unread === 'number') update.unread = Math.max(0, req.body.unread);
  await store.updateConversation(update);
  io.emit('conversation:updated', update);
  res.json(update);
});
api.get('/api/conversations/:id/messages', async (req, res) => {
  const all = await store.all();
  if (!all.conversations.some(x => x.id === req.params.id)) return fail(res, 'Conversation not found.', 404);
  res.json(all.messages.filter(x => x.conversationId === req.params.id));
});
api.post('/api/conversations/:id/messages', async (req, res) => {
  const item = await store.conversation(req.params.id);
  if (!item) return fail(res, 'Conversation not found.', 404);
  const { text = '', attachment, poll, announcement = false } = req.body || {};
  if (typeof text !== 'string' || text.length > 8000 || (!text.trim() && !attachment && !poll)) return fail(res, 'Message is empty or too long.');
  const message = { id: randomUUID(), conversationId: item.id, sender: 'me', text: text.trim(), time: timeNow(), status: 'sent', createdAt: new Date().toISOString(), ...(attachment ? { attachment } : {}), ...(poll ? { poll } : {}), ...(announcement ? { announcement: true } : {}) };
  await store.addMessage(message);
  const updated = { ...item, lastMessage: poll ? `Poll: ${poll.question}` : attachment ? `${text ? text.trim() + ' · ' : ''}📎 ${attachment.name}` : text.trim(), time: message.time, unread: 0 };
  await store.updateConversation(updated);
  io.to(`conversation:${item.id}`).emit('message:new', message);
  io.emit('conversation:updated', updated);
  res.status(201).json(message);
  setTimeout(async () => {
    const seen = { ...message, status: 'seen' };
    await store.updateMessage(seen);
    io.to(`conversation:${item.id}`).emit('message:updated', seen);
  }, 1250).unref();
});
api.patch('/api/messages/:id/reactions', async (req, res) => {
  const item = await store.message(req.params.id);
  if (!item) return fail(res, 'Message not found.', 404);
  const emoji = String(req.body.emoji || '').slice(0, 12);
  if (!emoji) return fail(res, 'An emoji is required.');
  let reactions = [...(item.reactions || [])];
  const found = reactions.find(x => x.emoji === emoji);
  if (found?.mine) { found.count -= 1; found.mine = false; if (found.count <= 0) reactions = reactions.filter(x => x.emoji !== emoji); }
  else if (found) { found.count += 1; found.mine = true; }
  else reactions.push({ emoji, count: 1, mine: true });
  const updated = { ...item, reactions };
  await store.updateMessage(updated);
  io.to(`conversation:${item.conversationId}`).emit('message:updated', updated);
  res.json(updated);
});
api.patch('/api/messages/:id/poll', async (req, res) => {
  const item = await store.message(req.params.id);
  const idx = Number(req.body.option);
  if (!item?.poll || !Number.isInteger(idx) || idx < 0 || idx >= item.poll.options.length) return fail(res, 'Invalid poll choice.');
  const options = item.poll.options.map((o, i) => ({ ...o, votes: Math.max(0, o.votes + (i === item.poll.voted ? -1 : 0) + (i === idx ? 1 : 0)) }));
  const updated = { ...item, poll: { ...item.poll, options, voted: idx } };
  await store.updateMessage(updated);
  io.to(`conversation:${item.conversationId}`).emit('message:updated', updated);
  res.json(updated);
});
api.get('/api/search', async (req, res) => {
  const term = String(req.query.q || '').trim().toLowerCase().slice(0, 150);
  if (!term) return res.json({ people: [], messages: [], files: [], links: [] });
  const { conversations, messages } = await store.all();
  const matchedMessages = messages.filter(x => x.text?.toLowerCase().includes(term)).slice(0, 20);
  res.json({ people: conversations.filter(x => (x.name + ' ' + x.role).toLowerCase().includes(term)).slice(0, 10), messages: matchedMessages, files: messages.filter(x => x.attachment?.name?.toLowerCase().includes(term)).slice(0, 10), links: messages.filter(x => x.text?.includes('http') && x.text.toLowerCase().includes(term)).slice(0, 10) });
});
api.post('/api/users/register', async (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 80);
  const email = String(req.body.email || '').trim().toLowerCase().slice(0, 160);
  const password = String(req.body.password || '');
  if (name.length < 2 || !/^\S+@\S+\.\S+$/.test(email) || password.length < 8) return fail(res, 'Enter a name, valid email and a password of at least 8 characters.');
  if (await store.user(email)) return fail(res, 'An account with this email already exists.', 409);
  const passwordHash = await bcrypt.hash(password, 10);
  await store.addUser({ name, email, passwordHash });
  res.status(201).json({ name, email });
});
api.post('/api/users/verify', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = await store.user(email);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return fail(res, 'Invalid email or password.', 401);
  res.json({ id: user.email, name: user.name, email: user.email });
});
api.post('/api/users/request-reset', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) return fail(res, 'Enter a valid email address.');
  const user = await store.user(email);
  let demoResetUrl;
  if (user) {
    const token = randomBytes(32).toString('hex');
    await store.setReset(email, createHash('sha256').update(token).digest('hex'), new Date(Date.now() + 15 * 60_000).toISOString());
    const base = process.env.AUTH_URL || `http://localhost:${port}`;
    const resetUrl = `${base}/login?reset=${token}&email=${encodeURIComponent(email)}`;
    if (process.env.RESEND_API_KEY && process.env.RESET_FROM_EMAIL) {
      await fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ from: process.env.RESET_FROM_EMAIL, to: [email], subject: 'Reset your HChat password', html: `<p>Click <a href="${resetUrl}">here to reset your HChat password</a>. This link expires in 15 minutes.</p>` }) });
    } else if (dev) demoResetUrl = `/login?reset=${token}&email=${encodeURIComponent(email)}`;
  }
  res.json({ message: 'If an account exists, a reset link has been created.', ...(demoResetUrl ? { demoResetUrl } : {}) });
});
api.post('/api/users/reset', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const token = String(req.body.token || '');
  const password = String(req.body.password || '');
  const reset = await store.getReset(email);
  if (!reset || token.length !== 64 || password.length < 8 || new Date(reset.expiresAt).getTime() < Date.now()) return fail(res, 'This link is invalid or expired. Request a new one.');
  const supplied = Buffer.from(createHash('sha256').update(token).digest('hex'));
  const stored = Buffer.from(reset.tokenHash);
  if (supplied.length !== stored.length || !timingSafeEqual(supplied, stored)) return fail(res, 'This link is invalid or expired.');
  await store.useReset(email, await bcrypt.hash(password, 10));
  res.json({ message: 'Password updated. You can now sign in.' });
});
api.get('/api/reminders', async (_req, res) => res.json((await store.all()).reminders));
api.post('/api/reminders', async (req, res) => {
  const { text, dueAt, conversationId } = req.body || {};
  if (!text?.trim() || !dueAt || !Number.isFinite(new Date(dueAt).getTime())) return fail(res, 'A reminder and valid time are required.');
  const reminder = { id: randomUUID(), text: String(text).trim().slice(0, 500), dueAt, conversationId, createdAt: new Date().toISOString() };
  await store.addReminder(reminder);
  io.emit('reminder:new', reminder);
  res.status(201).json(reminder);
});
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 }, fileFilter: (_req, file, cb) => { if (/^(image\/|application\/pdf|text\/|application\/(zip|msword|vnd\.))/.test(file.mimetype)) cb(null, true); else cb(new Error('Unsupported file type.')); } });
api.post('/api/upload', upload.single('file'), async (req, res) => {
  if (!req.file) return fail(res, 'Choose a file to upload.');
  try {
    let url;
    if (process.env.CLOUDINARY_URL) {
      cloudinary.config({ secure: true });
      const result = await new Promise((resolve, reject) => { const stream = cloudinary.uploader.upload_stream({ folder: 'hchat', resource_type: 'auto', use_filename: true }, (e, v) => e ? reject(e) : resolve(v)); stream.end(req.file.buffer); });
      url = result.secure_url;
    } else {
      const safeExt = path.extname(req.file.originalname).toLowerCase().replace(/[^.a-z0-9]/g, '').slice(0, 10);
      const filename = `${randomUUID()}${safeExt}`;
      fs.writeFileSync(path.join(process.cwd(), 'public/uploads', filename), req.file.buffer);
      url = `/uploads/${filename}`;
    }
    res.json({ kind: req.file.mimetype.startsWith('image/') ? 'image' : 'file', url, name: req.file.originalname.slice(0, 160), size: `${(req.file.size / (1024 * 1024)).toFixed(1)} MB` });
  } catch (e) { console.error(e); fail(res, 'Upload failed.', 500); }
});
api.post('/api/ai', async (req, res) => {
  const { action, conversationId, text, target = 'French' } = req.body || {};
  const all = await store.all();
  const conversation = all.conversations.find(x => x.id === conversationId);
  const recent = all.messages.filter(x => x.conversationId === conversationId).slice(-12);
  if (!conversation) return fail(res, 'Conversation not found.', 404);
  if (!['summary','suggest','translate'].includes(action)) return fail(res, 'Unknown action.');
  if (process.env.OPENAI_API_KEY) {
    try {
      const prompts = { summary: 'Summarize this conversation concisely in 2 sentences, with any next steps.', suggest: 'Suggest three short, natural, context-aware replies. Return them separated by newlines without numbering.', translate: `Translate the given text into ${target}. Return only the translation.` };
      const transcript = recent.map(m => `${m.sender === 'me' ? 'Herman' : m.senderName || conversation.name}: ${m.text || m.attachment?.name || ''}`).join('\n');
      const response = await fetch('https://api.openai.com/v1/chat/completions', { method:'POST', headers: { 'Content-Type':'application/json', Authorization:`Bearer ${process.env.OPENAI_API_KEY}` }, body: JSON.stringify({ model:'gpt-4o-mini', temperature:0.5, max_tokens:200, messages:[{role:'system',content:'You are HChat AI, a useful and concise chat copilot. Do not invent details.'},{role:'user',content:`${prompts[action]}\n\n${action === 'translate' ? String(text || '').slice(0,3000) : transcript}`} ] }) });
      if (response.ok) { const result = await response.json(); return res.json({ text: result.choices?.[0]?.message?.content?.trim() || '', mode:'AI' }); }
      console.error('AI API error:', response.status);
    } catch (e) { console.error('AI API unavailable:', e.message); }
  }
  if (action === 'summary') {
    if (conversationId === 'maya') return res.json({ text: 'You and Maya are finalizing the HChat launch visuals. Maya shared the homepage concept, you approved the softer blue direction, and she’ll send the final files shortly.', mode:'demo' });
    const last = recent.slice(-3).map(m => m.text || `Shared ${m.attachment?.name || 'a file'}`).filter(Boolean);
    return res.json({ text: `Recent conversation with ${conversation.name}: ${last.join(' · ')}${last.length ? ' Follow up on the latest update when you’re ready.' : 'No messages yet.'}`, mode:'demo' });
  }
  if (action === 'suggest') {
    const last = [...recent].reverse().find(x => x.sender === 'other')?.text?.toLowerCase() || '';
    let replies = last.includes('final files') ? ["Sounds great! Send them through whenever you’re ready.","Perfect — I’ll review everything when it lands.","Amazing work, Maya. Excited to share this with the team!"] : last.includes('moodboard') ? ["Love the direction — the color story feels right.","This is looking great. Can we explore the first option?", "Thanks for sharing! I'll leave feedback shortly."] : ["Sounds good to me — thanks for the update!", "Love this direction. Let's keep moving.", "Thanks! I'll take a closer look and get back to you."];
    return res.json({ text: replies.join('\n'), replies, mode:'demo' });
  }
  const sample = String(text || '').trim();
  const translations = {
    French: {"Amazing. I'll package everything up and send the final files shortly 🙌":"Génial. Je vais tout préparer et envoyer les fichiers finaux très bientôt 🙌", "Morning, Herman! The HChat launch assets are looking really strong. ✨":"Bonjour Herman ! Les visuels de lancement de HChat sont vraiment réussis. ✨"},
    Spanish: {"Amazing. I'll package everything up and send the final files shortly 🙌":"¡Genial! Voy a prepararlo todo y enviaré los archivos finales en breve 🙌", "Morning, Herman! The HChat launch assets are looking really strong. ✨":"¡Buenos días, Herman! Los materiales de lanzamiento de HChat se ven muy bien. ✨"}
  };
  const translated = translations[target]?.[sample];
  res.json({ text: translated || 'Live translation for this message needs an AI API key. Add OPENAI_API_KEY to your environment to translate any message.', mode: translated ? 'demo' : 'unavailable' });
});
io.on('connection', socket => {
  socket.on('conversation:join', id => { if (typeof id === 'string') socket.join(`conversation:${id}`); });
  socket.on('conversation:leave', id => socket.leave(`conversation:${id}`));
  socket.on('typing', ({ conversationId, name, isTyping }) => { if (typeof conversationId === 'string') socket.to(`conversation:${conversationId}`).emit('typing', { conversationId, name: String(name || 'Someone').slice(0,80), isTyping: !!isTyping }); });
});
api.use((error, req, res, next) => { if (req.path.startsWith('/api/')) return fail(res, error.message || 'Request failed.', error.code === 'LIMIT_FILE_SIZE' ? 413 : 400); next(error); });
api.all('*', (req, res) => handle(req, res));
httpServer.listen(port, hostname, () => console.log(`HChat ready at http://${hostname}:${port}`));
process.on('SIGTERM', async () => { httpServer.close(); await store.close(); process.exit(0); });
