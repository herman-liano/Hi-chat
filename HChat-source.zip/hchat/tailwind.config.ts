import type { Config } from 'tailwindcss';
const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: { extend: {
    colors: { ink: '#0B0B0F', midnight: '#111827', electric: '#3B82F6', violet: '#8B5CF6' },
    fontFamily: { sans: ['DM Sans Variable', 'sans-serif'], display: ['Plus Jakarta Sans Variable', 'sans-serif'] },
  } },
  plugins: [],
};
export default config;
