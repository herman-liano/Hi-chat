'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ArrowRight, Check, CheckCheck, Eye, EyeOff, LockKeyhole, Mail, ShieldCheck, Sparkles } from 'lucide-react';
import { Avatar, BrandMark, Wordmark } from '@/components/ui';

type Mode = 'signin'|'signup'|'recover'|'reset';
export default function LoginPage({ initialMode = 'signin', initialEmail = '', initialToken = '' }: { initialMode?: Mode; initialEmail?: string; initialToken?: string }){
  const router=useRouter();
  const [hydrated,setHydrated]=useState(false);
  const [mode,setMode]=useState<Mode>(initialMode);
  const [name,setName]=useState('');
  const [email,setEmail]=useState(initialEmail);
  const [password,setPassword]=useState('');
  const [confirm,setConfirm]=useState('');
  const [showPassword,setShowPassword]=useState(false);
  const [error,setError]=useState('');
  const [success,setSuccess]=useState('');
  const [loading,setLoading]=useState(false);
  const [resetLink,setResetLink]=useState('');
  const [resetToken,setResetToken]=useState(initialToken);
  const [googleEnabled,setGoogleEnabled]=useState(false);
  useEffect(()=>{
    setHydrated(true);
    fetch('/api/auth/providers').then(r=>r.json()).then(data=>setGoogleEnabled(Boolean(data.google))).catch(()=>{});
  },[]);
  function changeMode(next:Mode){setMode(next);setError('');setSuccess('');setResetLink('');setPassword('');setConfirm('');}
  async function submit(e:FormEvent){
    e.preventDefault();setError('');setSuccess('');setLoading(true);
    try{
      if(mode==='signup'){
        if(password!==confirm)throw new Error('Your passwords don’t match.');
        if(password.length<8)throw new Error('Use at least 8 characters for your password.');
        const res=await fetch('/api/users/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,email,password})});
        const result=await res.json();if(!res.ok)throw new Error(result.error||'Could not create your account.');
        const signed=await signIn('credentials',{email,password,redirect:false});
        if(signed?.error)throw new Error('Account created. Please sign in to continue.');
        router.push('/');router.refresh();return;
      }
      if(mode==='signin'){
        const signed=await signIn('credentials',{email,password,redirect:false});
        if(signed?.error)throw new Error('Incorrect email or password. Please try again.');
        router.push('/');router.refresh();return;
      }
      if(mode==='recover'){
        const res=await fetch('/api/users/request-reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})});
        const result=await res.json();if(!res.ok)throw new Error(result.error||'Unable to send a reset link.');
        setSuccess('If an account exists, your reset link is ready.');setResetLink(result.demoResetUrl||'');
      }
      if(mode==='reset'){
        if(password.length<8)throw new Error('Use at least 8 characters for your password.');
        if(password!==confirm)throw new Error('Your passwords don’t match.');
        const res=await fetch('/api/users/reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,token:resetToken,password})});
        const result=await res.json();if(!res.ok)throw new Error(result.error||'Could not reset your password.');
        changeMode('signin');setSuccess('Your password is updated. Sign in to continue.');
      }
    }catch(e){setError(e instanceof Error?e.message:'Something went wrong.');}
    finally{setLoading(false);}
  }
  return <div className="auth-page"><aside className="auth-showcase"><div className="auth-grid"/><div className="auth-light auth-light-blue"/><div className="auth-light auth-light-violet"/><div className="auth-showcase-top"><motion.div initial={{opacity:0,scale:.78,y:-8}} animate={{opacity:1,scale:1,y:0}} transition={{type:'spring',stiffness:240,damping:19,delay:.08}}><Wordmark/></motion.div><span>THE FUTURE OF CONVERSATION <i/></span></div><div className="auth-showcase-main"><motion.div initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} transition={{duration:.6}} className="auth-overline"><span className="auth-overline-star">✦</span> A more human way to connect</motion.div><motion.h1 initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{duration:.65,delay:.08}}>Every great idea<br/>starts with a<br/><em>conversation.</em></motion.h1><motion.p initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{duration:.6,delay:.16}}>Thoughtfully designed messaging for the people, ideas, and moments that move you forward.</motion.p><motion.div className="auth-preview" initial={{opacity:0,y:40,rotate:-2}} animate={{opacity:1,y:0,rotate:-2}} transition={{type:'spring',stiffness:100,damping:20,delay:.3}}><div className="auth-preview-header"><Avatar src="/avatars/maya.jpg" name="Maya Chen" size={37} online/><div><strong>Maya Chen</strong><span>Online now</span></div><span className="auth-preview-header-dots">•••</span></div><div className="auth-preview-body"><div className="preview-bubble incoming">Morning, Herman! The launch is looking incredible. ✨<span>10:24 AM</span></div><div className="preview-bubble outgoing">It really is. Can’t wait to share it with everyone.<span>10:29 AM <CheckCheck size={12}/></span></div><div className="preview-ai"><span><Sparkles size={14}/> HChat AI</span><strong>Looks like you&apos;re ready to make something great happen.</strong></div></div><div className="auth-preview-input">Write a message... <span><ArrowRight size={17}/></span></div></motion.div><motion.div className="auth-float-badge" initial={{opacity:0,scale:.8,y:15}} animate={{opacity:1,scale:1,y:0}} transition={{delay:.75,type:'spring',stiffness:180}}><span><Check size={17}/></span><div><strong>Simply connected.</strong><small>Exactly how it should feel.</small></div></motion.div></div><div className="auth-showcase-footer"><span>Simple. Fast. Intelligent.</span><span>Designed by Tadjodong Liano Herman © 2026</span></div></aside>
    <main className="auth-form-side"><div className="auth-mobile-brand"><motion.div initial={{opacity:0,scale:.8}} animate={{opacity:1,scale:1}} transition={{duration:.4}}><Wordmark/></motion.div></div><div className="auth-form-layout"><div className="auth-form-box"><div className="auth-form-overline"><span/> WELCOME TO HCHAT</div><AnimatePresence mode="wait"><motion.div key={mode} initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:.22}}>
      {mode==='signin'&&<><h2>Welcome back<span>.</span></h2><p className="auth-intro">The conversations that matter are waiting.</p></>}
      {mode==='signup'&&<><h2>Get started<span>.</span></h2><p className="auth-intro">A better way to connect starts here.</p></>}
      {mode==='recover'&&<><button className="auth-back-link" onClick={()=>changeMode('signin')}><ArrowLeft size={16}/> Back to sign in</button><h2>Forgot password<span>?</span></h2><p className="auth-intro">We’ll help you find your way back in.</p></>}
      {mode==='reset'&&<><h2>New password<span>.</span></h2><p className="auth-intro">Choose a secure password for your account.</p></>}
      {(mode==='signin'||mode==='signup')&&<div className="auth-tabs" role="tablist"><button role="tab" aria-selected={mode==='signin'} className={mode==='signin'?'active':''} onClick={()=>changeMode('signin')}>Sign in</button><button role="tab" aria-selected={mode==='signup'} className={mode==='signup'?'active':''} onClick={()=>changeMode('signup')}>Create account</button></div>}
      {error&&<div role="alert" className="auth-alert error">{error}</div>}{success&&<div role="status" className="auth-alert success">{success}</div>}
      <form className="auth-form" onSubmit={e=>void submit(e)}>{mode==='signup'&&<div className="auth-field"><label htmlFor="auth-name">Full name</label><input id="auth-name" value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" minLength={2} required disabled={!hydrated} autoComplete="name"/></div>}
        {mode!=='reset'&&<div className="auth-field"><label htmlFor="auth-email">Email address</label><div className="auth-input-icon"><Mail size={17}/><input id="auth-email" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required disabled={!hydrated} autoComplete="email"/></div></div>}
        {(mode==='signin'||mode==='signup'||mode==='reset')&&<div className="auth-field"><div className="auth-field-header"><label htmlFor="auth-password">{mode==='reset'?'New password':'Password'}</label>{mode==='signin'&&<button type="button" onClick={()=>changeMode('recover')}>Forgot password?</button>}</div><div className="auth-input-icon"><LockKeyhole size={17}/><input id="auth-password" type={showPassword?'text':'password'} value={password} onChange={e=>setPassword(e.target.value)} placeholder={mode==='signup'?'At least 8 characters':'Enter your password'} required disabled={!hydrated} minLength={mode==='signin'?1:8} autoComplete={mode==='signin'?'current-password':'new-password'}/><button type="button" onClick={()=>setShowPassword(x=>!x)} aria-label={showPassword?'Hide password':'Show password'}>{showPassword?<EyeOff size={18}/>:<Eye size={18}/>}</button></div></div>}
        {(mode==='signup'||mode==='reset')&&<div className="auth-field"><label htmlFor="auth-confirm">Confirm password</label><div className="auth-input-icon"><LockKeyhole size={17}/><input id="auth-confirm" type={showPassword?'text':'password'} value={confirm} onChange={e=>setConfirm(e.target.value)} placeholder="Repeat your password" required disabled={!hydrated} autoComplete="new-password"/></div></div>}
        <button className="auth-primary" disabled={loading||!hydrated} type="submit">{loading?'Please wait...':mode==='signin'?'Sign in':mode==='signup'?'Create account':mode==='recover'?'Get reset link':'Reset password'} {!loading&&<ArrowRight size={18}/>}</button>
      </form>
      {resetLink&&<a className="auth-reset-demo" href={resetLink}>Open your development reset link <ArrowRight size={16}/></a>}
      {(mode==='signin'||mode==='signup')&&<><div className="auth-or"><span/> or continue with <span/></div><button className="auth-google" onClick={()=>{if(googleEnabled)void signIn('google',{callbackUrl:'/'});else setError('Google sign-in needs Google OAuth keys. Use the demo workspace or email sign-in for now.');}}><svg width="19" height="19" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.28 5.48-4.83 7.18l7.73 6C44.36 38.03 46.98 31.86 46.98 24.55z"/><path fill="#FBBC05" d="M10.53 28.59A14.43 14.43 0 0 1 9.75 24c0-1.59.27-3.13.76-4.59l-7.98-6.2A23.92 23.92 0 0 0 0 24c0 3.87.93 7.51 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.91-5.8l-7.73-6c-2.15 1.45-4.92 2.3-8.18 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg> Continue with Google</button><button className="auth-demo-link" onClick={()=>router.push('/')}>Just looking around? <strong>Explore the demo <ArrowRight size={14}/></strong></button></>}
      {mode==='recover'&&<div className="auth-help"><ShieldCheck size={16}/> Reset links expire after 15 minutes. In local demo mode, we’ll show your link here.</div>}
      {mode==='reset'&&<button className="auth-demo-link" onClick={()=>changeMode('signin')}>Remembered your password? <strong>Sign in <ArrowRight size={14}/></strong></button>}
    </motion.div></AnimatePresence></div></div><div className="auth-form-footer"><span>© 2026 HChat. Made with intention.</span><span>Simple. Fast. Intelligent.</span></div></main>
  </div>;
}
