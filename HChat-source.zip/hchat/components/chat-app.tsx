'use client';
import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { io, type Socket } from 'socket.io-client';
import { useSession, signOut } from 'next-auth/react';
import {
  ArrowDownToLine, ArrowLeft, ArrowRight, ArrowUpRight, AtSign, Bell, BellOff, Check,
  CheckCheck, CheckCircle2, ChevronDown, ChevronRight, Clock3, Copy, Download, Ellipsis,
  FileText, Image as ImageIcon, Languages, Link2, ListFilter, Loader2, LogOut,
  Megaphone, MessageCircle, MessageSquare, Moon, MoreHorizontal, Paperclip, PanelRightClose,
  PanelRightOpen, Pin, Plus, Search, Send, Settings2, ShieldCheck, Smile, Sparkles,
  Trash2, UserPlus, UserRound, UsersRound, Volume2, VolumeX, X
} from 'lucide-react';
import { Avatar, BrandMark, ConversationAvatar, GroupAvatar, Modal, ModalHeading, Wordmark } from '@/components/ui';
import seed from '@/lib/seed.json';
import type { Attachment, Conversation, Member, Message, SearchTab } from '@/lib/types';

const initialData = seed as { conversations: Conversation[]; messages: Message[] };
const reactionEmojis = ['💜', '❤️', '😂', '🙌', '🔥', '👍'];
type Overlay = 'search'|'new'|'settings'|'profile'|'media'|'ai'|'reminder'|'poll'|'notifications'|'manage'|null;
type SettingsTab = 'Account'|'Security'|'Appearance'|'Notifications'|'Privacy'|'Language';
type Preferences = { theme: 'dark'|'light'; accent: 'blue'|'violet'; sound: boolean; desktopNotifications: boolean; readReceipts: boolean; language: string; displayName: string; bio: string };
const defaultPrefs: Preferences = { theme:'dark',accent:'blue',sound:true,desktopNotifications:true,readReceipts:true,language:'English',displayName:'Tadjodong Liano Herman',bio:'Building better ways to connect.' };
type Reminder = { id: string; text: string; dueAt: string; conversationId: string; createdAt: string };
type Notification = { id: string; title: string; detail: string; time: string; avatar: string; unread: boolean; conversationId: string };
const initialNotifications: Notification[] = [
  {id:'a',title:'Maya Chen',detail:'Shared a new launch concept with you',time:'10:26 AM',avatar:'/avatars/maya.jpg',unread:true,conversationId:'maya'},
  {id:'b',title:'Studio crew',detail:'Olivia added a new moodboard',time:'9:41 AM',avatar:'/avatars/olivia.jpg',unread:true,conversationId:'studio'},
  {id:'c',title:'Daniel Kim',detail:'Reacted to your message',time:'Yesterday',avatar:'/avatars/daniel.jpg',unread:false,conversationId:'daniel'}
];
async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
  return data as T;
}
const jsonPost = (body: unknown): RequestInit => ({ method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body) });
const timeNow = () => new Intl.DateTimeFormat('en-US',{hour:'numeric',minute:'2-digit',hour12:true}).format(new Date());
const firstName = (name: string) => name.split(' ')[0];
function Highlight({ text, query }: { text: string; query: string }) {
  if (!query.trim()) return <>{text}</>;
  const i = text.toLowerCase().indexOf(query.trim().toLowerCase());
  return i < 0 ? <>{text}</> : <>{text.slice(0,i)}<mark>{text.slice(i,i+query.trim().length)}</mark>{text.slice(i+query.trim().length)}</>;
}
function InlineText({ text }: { text:string }) {
  const parts = text.split(/(https?:\/\/[^\s]+)/g);
  return <>{parts.map((part,i) => part.startsWith('http') ? <a href={part} target="_blank" rel="noreferrer noopener" onClick={e=>e.stopPropagation()} key={i}>{part}</a> : <span key={i}>{part}</span>)}</>;
}

export default function ChatApp() {
  const { data: session } = useSession();
  const [conversations,setConversations] = useState<Conversation[]>(initialData.conversations);
  const [messages,setMessages] = useState<Message[]>(initialData.messages);
  const [selectedId,setSelectedId] = useState('maya');
  const [rightOpen,setRightOpen] = useState(true);
  const [mobileChat,setMobileChat] = useState(false);
  const [isMobile,setIsMobile] = useState(false);
  const [activeNav,setActiveNav] = useState<'chats'|'contacts'>('chats');
  const [listFilter,setListFilter] = useState<'All'|'Unread'|'Groups'>('All');
  const [overlay,setOverlay] = useState<Overlay>(null);
  const [profileTarget,setProfileTarget] = useState<string>('maya');
  const [selectedMedia,setSelectedMedia] = useState<Attachment|null>(null);
  const [draft,setDraft] = useState('');
  const [announcementMode,setAnnouncementMode] = useState(false);
  const [attachment,setAttachment] = useState<Attachment|null>(null);
  const [uploading,setUploading] = useState(false);
  const [emojiOpen,setEmojiOpen] = useState(false);
  const [toast,setToast] = useState('');
  const [searchTerm,setSearchTerm] = useState('');
  const [searchTab,setSearchTab] = useState<SearchTab>('All');
  const [settingsTab,setSettingsTab] = useState<SettingsTab>('Account');
  const [prefs,setPrefs] = useState<Preferences>(defaultPrefs);
  const [profileMenu,setProfileMenu] = useState(false);
  const [headerMenu,setHeaderMenu] = useState(false);
  const [muted,setMuted] = useState<string[]>([]);
  const [aiAction,setAiAction] = useState<'summary'|'suggest'|'translate'>('summary');
  const [aiText,setAiText] = useState('');
  const [aiReplies,setAiReplies] = useState<string[]>([]);
  const [aiLoading,setAiLoading] = useState(false);
  const [aiMode,setAiMode] = useState('');
  const [aiSourceText,setAiSourceText] = useState('');
  const [translateTarget,setTranslateTarget] = useState('French');
  const [reminderText,setReminderText] = useState('');
  const [reminderWhen,setReminderWhen] = useState('Tomorrow morning');
  const [reminderCustom,setReminderCustom] = useState('');
  const [reminders,setReminders] = useState<Reminder[]>([]);
  const [notifications,setNotifications] = useState(initialNotifications);
  const [newTab,setNewTab] = useState<'message'|'group'>('message');
  const [newGroupName,setNewGroupName] = useState('');
  const [groupPeople,setGroupPeople] = useState<string[]>([]);
  const [pollQuestion,setPollQuestion] = useState('');
  const [pollOptions,setPollOptions] = useState(['','']);
  const [remoteTyping,setRemoteTyping] = useState('');
  const [demoTyping,setDemoTyping] = useState(true);
  const [targetMessageId,setTargetMessageId] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const socketRef = useRef<Socket|null>(null);
  const typingTimerRef = useRef<ReturnType<typeof setTimeout>|null>(null);
  const toastTimerRef = useRef<ReturnType<typeof setTimeout>|null>(null);
  const selectedIdRef = useRef(selectedId);
  const alertedRemindersRef = useRef(new Set<string>());
  const selected = conversations.find(x => x.id === selectedId) || conversations[0];
  const selectedMessages = messages.filter(x => x.conversationId === selected?.id);
  const contacts = conversations.filter(x => x.kind === 'direct');
  const newPeople = contacts;
  const unreadTotal = conversations.reduce((sum,x) => sum + x.unread,0);
  const notificationTotal = notifications.filter(x=>x.unread).length;
  const displayName = session?.user?.name || prefs.displayName;

  const notify = useCallback((message:string) => {
    setToast(message);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(()=>setToast(''),3600);
  },[]);
  useEffect(() => {
    try {
      const saved = localStorage.getItem('hchat-preferences');
      if (saved) setPrefs(p=>({...p,...JSON.parse(saved)}));
      const savedMuted = localStorage.getItem('hchat-muted');
      if (savedMuted) setMuted(JSON.parse(savedMuted));
    } catch { /* browser storage not available */ }
  },[]);
  useEffect(() => { document.documentElement.dataset.theme = prefs.theme; document.documentElement.dataset.accent = prefs.accent; localStorage.setItem('hchat-preferences',JSON.stringify(prefs)); },[prefs]);
  useEffect(() => {
    const checkReminders = () => {
      for (const item of reminders) {
        if (new Date(item.dueAt).getTime() > Date.now() || alertedRemindersRef.current.has(item.id)) continue;
        alertedRemindersRef.current.add(item.id);
        notify(`Reminder: ${item.text}`);
        if (prefs.desktopNotifications && 'Notification' in window && window.Notification.permission === 'granted') {
          new window.Notification('HChat reminder', { body: item.text, icon: '/avatars/herman.jpg' });
        }
      }
    };
    checkReminders();
    const timer = window.setInterval(checkReminders, 30_000);
    return () => window.clearInterval(timer);
  },[reminders,prefs.desktopNotifications,notify]);
  useEffect(() => { localStorage.setItem('hchat-muted',JSON.stringify(muted)); },[muted]);
  useEffect(() => { selectedIdRef.current = selectedId; },[selectedId]);
  useEffect(() => {
    const query = window.matchMedia('(max-width: 650px)');
    const sync = () => setIsMobile(query.matches);
    sync(); query.addEventListener('change', sync);
    return () => query.removeEventListener('change', sync);
  }, []);
  useEffect(() => {
    const timer = setTimeout(()=>setDemoTyping(false),11000);
    request<{conversations:Conversation[]; messages:Message[];reminders:Reminder[]}>('/api/bootstrap').then(data=>{
      setConversations(data.conversations);
      setMessages(data.messages);
      setReminders(data.reminders || []);
    }).catch(()=>{});
    const socket = io({path:'/socket.io',transports:['websocket','polling'],reconnectionAttempts:6});
    socketRef.current = socket;
    socket.on('message:new',(message:Message)=>setMessages(prev=>prev.some(x=>x.id===message.id)?prev:[...prev,message]));
    socket.on('message:updated',(message:Message)=>setMessages(prev=>prev.map(x=>x.id===message.id?message:x)));
    socket.on('conversation:new',(conversation:Conversation)=>setConversations(prev=>prev.some(x=>x.id===conversation.id)?prev:[conversation,...prev]));
    socket.on('conversation:updated',(conversation:Conversation)=>setConversations(prev=>{
      const current=prev.find(x=>x.id===conversation.id);
      if (!current) return [conversation,...prev];
      const merged={...conversation,unread:conversation.id===selectedIdRef.current?0:Math.max(current.unread,conversation.unread)};
      return [merged,...prev.filter(x=>x.id!==conversation.id)];
    }));
    socket.on('reminder:new',(item:Reminder)=>setReminders(prev=>prev.some(x=>x.id===item.id)?prev:[item,...prev]));
    socket.on('typing',({conversationId,name,isTyping}:{conversationId:string;name:string;isTyping:boolean})=>{if(conversationId===selectedIdRef.current)setRemoteTyping(isTyping?name:'');});
    return ()=>{clearTimeout(timer);socket.disconnect();socketRef.current=null;};
  },[]);
  useEffect(()=>{
    socketRef.current?.emit('conversation:join',selectedId);
    setRemoteTyping('');
    return ()=>{socketRef.current?.emit('conversation:leave',selectedId);};
  },[selectedId]);
  useEffect(()=>{
    if (!scrollRef.current) return;
    const node=scrollRef.current;
    requestAnimationFrame(()=>{node.scrollTop=node.scrollHeight;});
  },[selectedId,selectedMessages.length,demoTyping,remoteTyping,mobileChat]);
  useEffect(()=>{
    if (!targetMessageId || overlay) return;
    const timer=setTimeout(()=>{document.getElementById(`message-${targetMessageId}`)?.scrollIntoView({behavior:'smooth',block:'center'});setTargetMessageId('');},230);
    return ()=>clearTimeout(timer);
  },[targetMessageId,overlay,selectedId]);
  useEffect(()=>{
    const onKey=(e:globalThis.KeyboardEvent)=>{
      if ((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k') {e.preventDefault();setOverlay('search');setSearchTerm('');}
      if (e.key==='Escape') {setOverlay(null);setEmojiOpen(false);setProfileMenu(false);setHeaderMenu(false);}
    };
    window.addEventListener('keydown',onKey);return()=>window.removeEventListener('keydown',onKey);
  },[]);

  function pickConversation(id:string){
    setAnnouncementMode(false);setSelectedId(id);setMobileChat(true);setOverlay(null);setHeaderMenu(false);
    setConversations(prev=>prev.map(x=>x.id===id?{...x,unread:0}:x));
    request<Conversation>(`/api/conversations/${id}`, {method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({unread:0})}).catch(()=>{});
  }
  async function sendMessage(payload?:{text?:string;attachment?:Attachment|null;poll?:Message['poll'];announcement?:boolean}) {
    if(!selected||uploading)return;
    const text=(payload?.text??draft).trim();
    const file=payload?.attachment===undefined?attachment:payload.attachment;
    const isAnnouncement=payload?.announcement??announcementMode;
    if(!text&&!file&&!payload?.poll)return;
    const tempId=`temp-${Date.now()}-${Math.random()}`;
    const optimistic:Message={id:tempId,conversationId:selected.id,sender:'me',text,time:timeNow(),status:'sending',...(file?{attachment:file}:{}),...(payload?.poll?{poll:payload.poll}:{}),...(isAnnouncement?{announcement:true}:{})};
    setMessages(prev=>[...prev,optimistic]);setDraft('');setAttachment(null);setEmojiOpen(false);setAnnouncementMode(false);
    setConversations(prev=>[{...selected,lastMessage:text||file?.name||`Poll: ${payload?.poll?.question}`,time:optimistic.time,unread:0},...prev.filter(x=>x.id!==selected.id)]);
    try {
      const saved=await request<Message>(`/api/conversations/${selected.id}/messages`,jsonPost({text,attachment:file,poll:payload?.poll,announcement:isAnnouncement}));
      setMessages(prev=>{const other=prev.filter(x=>x.id!==tempId);return other.some(x=>x.id===saved.id)?other:[...other,saved];});
    } catch(e) {
      setMessages(prev=>prev.filter(x=>x.id!==tempId));setDraft(text);if(file)setAttachment(file);if(isAnnouncement)setAnnouncementMode(true);notify(e instanceof Error?e.message:'Could not send message.');
    }
    socketRef.current?.emit('typing',{conversationId:selected.id,name:displayName,isTyping:false});
  }
  function handleComposerKey(e:KeyboardEvent<HTMLTextAreaElement>){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();void sendMessage();}}
  function handleTyping(e:ChangeEvent<HTMLTextAreaElement>){
    setDraft(e.target.value);
    if(!selected)return;
    socketRef.current?.emit('typing',{conversationId:selected.id,name:displayName,isTyping:true});
    if(typingTimerRef.current)clearTimeout(typingTimerRef.current);
    typingTimerRef.current=setTimeout(()=>socketRef.current?.emit('typing',{conversationId:selected.id,name:displayName,isTyping:false}),1200);
  }
  async function uploadFile(e:ChangeEvent<HTMLInputElement>){
    const file=e.target.files?.[0];if(!file)return;
    if(file.size>10*1024*1024){notify('Files must be 10 MB or smaller.');e.target.value='';return;}
    setUploading(true);
    try {const form=new FormData();form.append('file',file);const saved=await request<Attachment>('/api/upload',{method:'POST',body:form});setAttachment(saved);inputRef.current?.focus();notify('File ready to send');}
    catch(error){notify(error instanceof Error?error.message:'Upload failed.');}
    finally{setUploading(false);e.target.value='';}
  }
  async function reactTo(message:Message,emoji:string){
    try {const updated=await request<Message>(`/api/messages/${message.id}/reactions`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({emoji})});setMessages(prev=>prev.map(x=>x.id===message.id?updated:x));}
    catch(error){notify(error instanceof Error?error.message:'Unable to react.');}
  }
  async function vote(message:Message,option:number){
    try {const updated=await request<Message>(`/api/messages/${message.id}/poll`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({option})});setMessages(prev=>prev.map(x=>x.id===message.id?updated:x));}
    catch(error){notify(error instanceof Error?error.message:'Could not submit your vote.');}
  }
  const openAI=useCallback(async(action:'summary'|'suggest'|'translate',source?:string,target='French')=>{
    setAiAction(action);setAiSourceText(source||'');setTranslateTarget(target);setAiText('');setAiReplies([]);setAiMode('');setAiLoading(true);setOverlay('ai');
    try {const result=await request<{text:string;replies?:string[];mode:string}>('/api/ai',jsonPost({action,conversationId:selectedIdRef.current,text:source,target}));setAiText(result.text);setAiReplies(result.replies||[]);setAiMode(result.mode);}
    catch(e){setAiText(e instanceof Error?e.message:'Unable to connect to HChat AI.');setAiMode('error');}
    finally{setAiLoading(false);}
  },[]);
  function openReminder(){setReminderText(selected?.kind==='group'?`Follow up with ${selected.name}`:`Follow up with ${selected?.name||'this conversation'}`);setReminderWhen('Tomorrow morning');setOverlay('reminder');}
  async function createReminder(e:FormEvent){
    e.preventDefault();
    const due=new Date();
    if(reminderWhen==='Later today')due.setHours(due.getHours()+3);
    else if(reminderWhen==='Tomorrow morning'){due.setDate(due.getDate()+1);due.setHours(9,0,0,0);}
    else if(reminderWhen==='Next week'){due.setDate(due.getDate()+7);due.setHours(9,0,0,0);}
    else if(reminderCustom)due.setTime(new Date(reminderCustom).getTime());
    else return notify('Choose a date and time.');
    if(due.getTime()<=Date.now())return notify('Choose a time in the future.');
    try {const item=await request<Reminder>('/api/reminders',jsonPost({text:reminderText,dueAt:due.toISOString(),conversationId:selectedId}));setReminders(prev=>prev.some(x=>x.id===item.id)?prev:[item,...prev]);setOverlay(null);notify('Reminder created — you’ll see it in notifications.');}
    catch(error){notify(error instanceof Error?error.message:'Could not create reminder.');}
  }
  async function createPoll(e:FormEvent){
    e.preventDefault();const opts=pollOptions.map(x=>x.trim()).filter(Boolean);
    if(!pollQuestion.trim()||opts.length<2)return notify('Add a question and at least two choices.');
    setOverlay(null);await sendMessage({text:'',poll:{question:pollQuestion.trim(),options:opts.map(label=>({label,votes:0}))}});
    setPollQuestion('');setPollOptions(['','']);notify('Poll shared with the conversation.');
  }
  function toggleMute(){if(!selected)return;const isMuted=muted.includes(selected.id);setMuted(prev=>isMuted?prev.filter(x=>x!==selected.id):[...prev,selected.id]);notify(isMuted?'Notifications turned on':'Conversation muted');setHeaderMenu(false);}
  function openProfile(id?:string){setProfileTarget(id||selectedId);setOverlay('profile');}
  function openMedia(item:Attachment){setSelectedMedia(item);setOverlay('media');}
  const sharedMedia=messages.filter(x=>x.conversationId===selected?.id&&x.attachment?.kind==='image').map(x=>x.attachment!) as Attachment[];
  const mediaGallery=selectedMedia?(sharedMedia.some(x=>x.url===selectedMedia.url)?sharedMedia:[selectedMedia]):[];
  const sharedFiles=messages.filter(x=>x.conversationId===selected?.id&&x.attachment?.kind==='file').map(x=>x.attachment!) as Attachment[];
  if(selected?.id==='maya')sharedMedia.push({kind:'image',url:'/media/brand-exploration.svg',name:'Brand exploration.svg',size:'2.4 MB'},{kind:'image',url:'/media/interface-study.svg',name:'Interface study.svg',size:'1.6 MB'});
  if(selected?.id==='maya')sharedFiles.push({kind:'file',url:'/media/launch-concept.svg',name:'HChat brand guidelines.pdf',size:'4.8 MB'});
  const listConversations=(activeNav==='contacts'?contacts:conversations).filter(x=>activeNav==='contacts'||listFilter==='All'||(listFilter==='Unread'?x.unread>0:x.kind==='group'));
  const searchResults=useMemo(()=>{
    const q=searchTerm.toLowerCase().trim();
    return {
      people:conversations.filter(x=>!q||`${x.name} ${x.role}`.toLowerCase().includes(q)).slice(0,6),
      messages:messages.filter(x=>x.text&&(!q?['maya','studio'].includes(x.conversationId):x.text.toLowerCase().includes(q))).slice(0,8),
      files:messages.filter(x=>x.attachment&&(!q||x.attachment.name.toLowerCase().includes(q))).slice(0,6),
      links:messages.filter(x=>x.text?.match(/https?:\/\//)&&(!q||x.text.toLowerCase().includes(q))).slice(0,6)
    };
  },[searchTerm,conversations,messages]);
  const searchCount=searchResults.people.length+searchResults.messages.length+searchResults.files.length+searchResults.links.length;

  return <div className="app-root"><div className="app-shell">
    <nav className="nav-rail" aria-label="Main navigation">
      <button className="rail-logo" title="HChat home" onClick={()=>{setActiveNav('chats');setMobileChat(false);setOverlay(null);}}><BrandMark size={39}/></button>
      <div className="rail-links">
        <button className={`rail-btn ${activeNav==='chats'?'active':''}`} aria-label="Messages" title="Messages" onClick={()=>{setActiveNav('chats');setMobileChat(false);}}><MessageSquare size={21} strokeWidth={1.9}/>{unreadTotal>0&&<i className="rail-unread-dot"/>}</button>
        <button className={`rail-btn ${activeNav==='contacts'?'active':''}`} aria-label="Contacts" title="Contacts" onClick={()=>{setActiveNav('contacts');setMobileChat(false);}}><UsersRound size={21} strokeWidth={1.9}/></button>
        <button className="rail-btn" aria-label="Smart search" title="Smart search" onClick={()=>{setSearchTerm('');setOverlay('search');}}><Search size={21} strokeWidth={1.9}/></button>
        <div className="rail-separator"/>
        <button className="rail-btn rail-ai" aria-label="HChat AI" title="HChat AI" onClick={()=>void openAI('summary')}><Sparkles size={20} strokeWidth={1.9}/></button>
      </div>
      <div className="rail-bottom">
        <button className="rail-btn" aria-label="Notifications" title="Notifications" onClick={()=>setOverlay('notifications')}><Bell size={20} strokeWidth={1.9}/>{notificationTotal>0&&<i className="notification-dot"/>}</button>
        <button className="rail-btn" aria-label="Settings" title="Settings" onClick={()=>{setSettingsTab('Account');setOverlay('settings');}}><Settings2 size={20} strokeWidth={1.9}/></button>
        <div className="rail-bottom-separator"/>
        <button className="rail-profile" aria-label="Profile menu" title="Your profile" onClick={()=>setProfileMenu(x=>!x)}><Avatar src={session?.user?.image||'/avatars/herman.jpg'} name={displayName} size={35} online/></button>
      </div>
      <AnimatePresence>{profileMenu&&<motion.div className="profile-popover" initial={{opacity:0,scale:.95,y:8}} animate={{opacity:1,scale:1,y:0}} exit={{opacity:0,scale:.96,y:5}}>
        <div className="profile-popover-top"><Avatar src={session?.user?.image||'/avatars/herman.jpg'} name={displayName} size={38}/><div><strong>{displayName}</strong><span>{session?.user?.email||'Your workspace'}</span></div></div>
        <button onClick={()=>{setProfileMenu(false);openProfile('me');}}><UserRound size={16}/> My profile</button>
        <button onClick={()=>{setProfileMenu(false);setOverlay('settings');}}><Settings2 size={16}/> Settings</button>
        <div className="popover-line"/>
        <button onClick={()=>{setProfileMenu(false);if(session)void signOut({redirectTo:'/login'});else window.location.href='/login';}}><LogOut size={16}/> {session?'Sign out':'Go to sign in'}</button>
      </motion.div>}</AnimatePresence>
    </nav>

    <div role={isMobile&&!mobileChat?"main":"complementary"} className={`conversations-panel ${mobileChat?'mobile-list-hidden':''}`} aria-label="Conversations">
      <div className="sidebar-workspace"><Wordmark compact/><button className="workspace-switch" aria-label="Current workspace" onClick={()=>notify('You’re in your personal HChat workspace.')}><ChevronDown size={16}/></button></div>
      <div className="sidebar-title-row"><div><div className="eyebrow">YOUR SPACE <span className="eyebrow-line"/></div><h1>{activeNav==='contacts'?'People':'Messages'}</h1><p>{activeNav==='contacts'?'The people who make it happen.':'Everything in one place.'}</p></div><button className="new-chat-btn" title={activeNav==='contacts'?'New contact':'New message'} aria-label="New conversation" onClick={()=>{setNewTab('message');setOverlay('new');}}><Plus size={19} strokeWidth={2}/></button></div>
      <button className="sidebar-search" onClick={()=>{setSearchTerm('');setOverlay('search');}} aria-label="Search messages, files and people"><Search size={17}/><span>Search anything...</span><kbd>⌘ K</kbd></button>
      {activeNav==='chats'&&<div className="filter-tabs" role="tablist" aria-label="Filter conversations">{(['All','Unread','Groups'] as const).map(tab=><button key={tab} role="tab" aria-selected={listFilter===tab} className={listFilter===tab?'selected':''} onClick={()=>setListFilter(tab)}>{tab}{tab==='Unread'&&unreadTotal>0&&<span className="filter-count">{unreadTotal}</span>}</button>)}</div>}
      {activeNav==='contacts'&&<div className="sidebar-section-label">ALL CONTACTS <span>{contacts.length}</span></div>}
      <div className="conversation-scroll">
        {listConversations.length===0?<div className="list-empty"><MessageCircle size={24}/><strong>All caught up</strong><span>No conversations here yet.</span></div>:listConversations.map((c,i)=><motion.button key={c.id} layout initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} transition={{delay:Math.min(i*.035,.22)}} className={`conversation-item ${selectedId===c.id?'selected':''}`} onClick={()=>pickConversation(c.id)}>
          <ConversationAvatar conversation={c} size={47}/><span className="conversation-copy"><span className="conversation-top"><strong>{c.name}</strong><small>{c.time}</small></span><span className="conversation-bottom"><span className={c.unread?'unread-preview':''}>{activeNav==='contacts'?c.role:c.lastMessage}</span>{c.unread>0&&<b className="unread-badge">{c.unread}</b>}</span></span>
        </motion.button>)}
      </div>
      <div className="sidebar-footer"><div className="invite-mini"><div className="invite-icon"><UserPlus size={18}/></div><div><strong>Better together</strong><span>Invite someone to HChat</span></div><button title="Copy invite link" aria-label="Copy invite link" onClick={()=>{void navigator.clipboard?.writeText(`${window.location.origin}/login`);notify('Invite link copied to clipboard.');}}><ArrowUpRight size={17}/></button></div><div className="sidebar-credit">Crafted by Tadjodong Liano Herman <span>✦</span></div></div>
    </div>

    <main className={`chat-panel ${mobileChat?'mobile-chat-open':''}`} aria-label="Chat window">
      {selected ? <>
        <header className="chat-header"><div className="chat-header-person"><button className="mobile-back" aria-label="Back to conversations" onClick={()=>setMobileChat(false)}><ArrowLeft size={21}/></button><button className="header-avatar-button" onClick={()=>openProfile()} aria-label={`View ${selected.name}'s profile`}><ConversationAvatar conversation={selected} size={43}/></button><div className="chat-header-identity"><h1><button onClick={()=>openProfile()}>{selected.name}</button></h1><span>{remoteTyping?`${remoteTyping} is typing...`:selected.kind==='group'?`${selected.members?.length||0} members · Tap to view details`:selected.online?<><i className="tiny-online"/>Online now</>:selected.status}</span></div></div>
          <div className="header-actions"><button className="icon-btn" aria-label="Search in conversation" title="Search in conversation" onClick={()=>{setSearchTerm('');setOverlay('search');}}><Search size={19}/></button><button className="icon-btn header-hide-small" aria-label="Create reminder" title="Create reminder" onClick={openReminder}><Clock3 size={19}/></button><span className="header-divider"/><button className="icon-btn header-hide-small" aria-label={rightOpen?'Hide details':'Show details'} title={rightOpen?'Hide details':'Show details'} onClick={()=>setRightOpen(x=>!x)}>{rightOpen?<PanelRightClose size={19}/>:<PanelRightOpen size={19}/>}</button><div className="header-menu-wrap"><button className="icon-btn" aria-label="More conversation actions" onClick={()=>setHeaderMenu(x=>!x)}><MoreHorizontal size={21}/></button>{headerMenu&&<div className="header-menu"><button onClick={()=>{setHeaderMenu(false);openProfile();}}><UserRound size={16}/> View details</button><button onClick={()=>{setHeaderMenu(false);void openAI('summary');}}><Sparkles size={16}/> Summarize chat</button>{selected.kind==='group'&&<><button onClick={()=>{setHeaderMenu(false);setOverlay('poll');}}><ListFilter size={16}/> Create a poll</button><button onClick={()=>{setHeaderMenu(false);setAnnouncementMode(true);inputRef.current?.focus();notify('Announcement mode is on.');}}><Megaphone size={16}/> New announcement</button></>}<div className="popover-line"/><button onClick={toggleMute}>{muted.includes(selected.id)?<Volume2 size={16}/>:<VolumeX size={16}/>} {muted.includes(selected.id)?'Unmute conversation':'Mute conversation'}</button></div>}</div></div>
        </header>
        <div className="chat-message-area" ref={scrollRef}>
          <div className="chat-message-inner">
            <div className="date-divider"><span>{new Intl.DateTimeFormat('en-US',{month:'long',day:'numeric'}).format(new Date())} <span className="date-separator">·</span> Today</span></div>
            {selectedMessages.length===0?<div className="empty-conversation"><div className="empty-conversation-icon"><MessageSquare size={29}/></div><h3>A new conversation starts here.</h3><p>Say hello to {selected.name} and make something great happen.</p></div>:selectedMessages.map((message,i)=>{
              const mine=message.sender==='me';const next=selectedMessages[i+1];
              const showAvatar=!mine&&(!next||next.sender!==message.sender||(selected.kind==='group'&&next.senderName!==message.senderName));
              const showMeta=!next||next.sender!==message.sender||(selected.kind==='group'&&next.senderName!==message.senderName);
              return <motion.div id={`message-${message.id}`} key={message.id} className={`message-row ${mine?'outbound':'inbound'} ${message.announcement?'announcement-row':''}`} initial={{opacity:0,y:11,scale:.98}} animate={{opacity:1,y:0,scale:1}} transition={{duration:.32,delay:Math.min(i*.027,.19),ease:[.2,.8,.2,1]}}>
                {!mine&&<span className="message-avatar-slot">{showAvatar?<Avatar src={selected.kind==='group'?message.avatar:selected.avatar} name={message.senderName||selected.name} size={29}/>:null}</span>}
                <div className="message-stack">
                  {selected.kind==='group'&&!mine&&message.senderName&&<span className="message-sender-name">{message.senderName}</span>}
                  {message.announcement&&<span className="announcement-label"><Megaphone size={12}/> Announcement</span>}
                  {message.text&&<div className={`message-bubble ${mine?'bubble-mine':'bubble-theirs'}`}><InlineText text={message.text}/><div className="reaction-toolbar" aria-label="React to message">{reactionEmojis.slice(0,4).map(emoji=><button key={emoji} title={`React ${emoji}`} onClick={()=>void reactTo(message,emoji)}>{emoji}</button>)}<button title="More reactions" onClick={()=>void reactTo(message,'👍')}><Plus size={13}/></button>{!mine&&<button title="Translate message" onClick={()=>void openAI('translate',message.text)}><Languages size={13}/></button>}</div></div>}
                  {message.attachment&&<div className={`message-attachment ${mine?'attachment-mine':''}`}>
                    {message.attachment.kind==='image'?<><button className="attachment-image" onClick={()=>openMedia(message.attachment!)} aria-label={`Open ${message.attachment.name}`}><img src={message.attachment.url} alt={message.attachment.name} loading="eager" onLoad={()=>{const node=scrollRef.current;if(node&&node.scrollHeight-node.scrollTop-node.clientHeight<180)node.scrollTop=node.scrollHeight;}}/></button><div className="attachment-caption"><span className="attachment-icon"><ImageIcon size={15}/></span><div><strong>{message.attachment.name}</strong><small>{message.attachment.size} · Image</small></div><button title="View image" aria-label="View image" onClick={()=>openMedia(message.attachment!)}><ArrowUpRight size={16}/></button></div></>:
                    <div className="file-attachment"><span className="file-icon"><FileText size={21}/></span><div><strong>{message.attachment.name}</strong><span>{message.attachment.size} · Document</span></div><a href={message.attachment.url} download={message.attachment.name} aria-label={`Download ${message.attachment.name}`}><ArrowDownToLine size={18}/></a></div>}
                  </div>}
                  {message.poll&&<div className="poll-card"><div className="poll-eyebrow"><ListFilter size={14}/> GROUP POLL</div><h4>{message.poll.question}</h4><div className="poll-options">{message.poll.options.map((option,index)=>{const total=message.poll!.options.reduce((sum,x)=>sum+x.votes,0);const percent=total?Math.round(option.votes/total*100):0;return <button className={`poll-choice ${message.poll!.voted===index?'voted':''}`} onClick={()=>void vote(message,index)} key={index}><span className="poll-fill" style={{width:`${percent}%`}}/><span className="poll-radio">{message.poll!.voted===index&&<Check size={11}/>}</span><strong>{option.label}</strong><small>{percent}%</small></button>;})}</div><div className="poll-footer">{message.poll.options.reduce((sum,x)=>sum+x.votes,0)} votes <span>·</span> {message.poll.voted!==undefined?'You voted':'Tap to vote'}</div></div>}
                  {message.reactions?.length? <div className="message-reactions">{message.reactions.map(r=><button key={r.emoji} className={r.mine?'mine':''} onClick={()=>void reactTo(message,r.emoji)} title="Toggle reaction">{r.emoji}<span>{r.count}</span></button>)}</div>:null}
                  {showMeta&&<div className="message-meta"><span>{message.time}</span>{mine&&(message.status==='sending'?<Loader2 size={12} className="spin"/>:message.status==='seen'?<CheckCheck size={15} className="seen-check"/>:message.status==='delivered'?<CheckCheck size={15}/>:<Check size={14}/>)}</div>}
                </div>
              </motion.div>;
            })}
            {(remoteTyping||(demoTyping&&selected.id==='maya'))&&<div className="typing-row"><Avatar src={selected.avatar||'/avatars/maya.jpg'} name={selected.name} size={29}/><div className="typing-bubble"><i/><i/><i/></div><span>{remoteTyping||firstName(selected.name)} is typing</span></div>}
          </div>
        </div>
        <div className="composer-wrap">{announcementMode&&<div className="announcement-composer-bar"><Megaphone size={15}/> Announcement to {selected.name}<button title="Cancel announcement" aria-label="Cancel announcement" onClick={()=>setAnnouncementMode(false)}><X size={15}/></button></div>}<div className="composer-container">
          {attachment&&<div className="composer-attachment"><div className="composer-file-icon">{attachment.kind==='image'?<ImageIcon size={19}/>:<FileText size={19}/>}</div><div><strong>{attachment.name}</strong><span>{attachment.size} · Ready to send</span></div><button aria-label="Remove attachment" onClick={()=>setAttachment(null)}><X size={17}/></button></div>}
          <div className="composer-input-row"><textarea ref={inputRef} value={draft} onChange={handleTyping} onKeyDown={handleComposerKey} placeholder={`Message ${selected.kind==='group'?selected.name:firstName(selected.name)}...`} aria-label="Write a message" rows={1}/></div>
          <div className="composer-toolbar"><div className="composer-tools"><input ref={fileRef} type="file" accept="image/*,.pdf,.txt,.zip,.doc,.docx" hidden onChange={e=>void uploadFile(e)}/><button title="Attach a file" aria-label="Attach a file" onClick={()=>fileRef.current?.click()} disabled={uploading}>{uploading?<Loader2 size={19} className="spin"/>:<Paperclip size={19}/>}</button><div className="emoji-anchor"><button title="Add emoji" aria-label="Add emoji" onClick={()=>setEmojiOpen(x=>!x)}><Smile size={19}/></button>{emojiOpen&&<div className="emoji-popover"><div>Pick an emoji</div><section>{['😊','✨','💜','🙌','🔥','👍','❤️','😂','👀','🚀','🎉','✅','💡','👋','🙏','💬'].map(emoji=><button key={emoji} onClick={()=>{setDraft(prev=>prev+emoji);setEmojiOpen(false);inputRef.current?.focus();}}>{emoji}</button>)}</section></div>}</div>{selected.kind==='group'&&<button title="Create a poll" aria-label="Create a poll" onClick={()=>setOverlay('poll')}><ListFilter size={19}/></button>}<button className="composer-ai-button" title="Write with AI" aria-label="Suggest a reply with AI" onClick={()=>void openAI('suggest')}><Sparkles size={18}/><span>AI assist</span></button></div><div className="composer-send-side"><span>Enter to send</span><button className="send-button" aria-label="Send message" disabled={(!draft.trim()&&!attachment)||uploading} onClick={()=>void sendMessage()}><Send size={18} fill="currentColor" strokeWidth={1.8}/></button></div></div>
        </div><div className="composer-hint">Made for the moments that matter <span>✦</span> HChat</div></div>
      </>:<div className="no-conversation">Choose a conversation to get started.</div>}
    </main>

    {selected&&rightOpen&&<aside className="details-panel" aria-label="Conversation details"><div className="details-header"><strong>Details</strong><button className="icon-btn" aria-label="Hide details" onClick={()=>setRightOpen(false)}><X size={18}/></button></div><div className="details-scroll">
      <div className="details-profile"><button className="details-avatar" onClick={()=>openProfile()} aria-label={`View ${selected.name}'s profile`}><ConversationAvatar conversation={selected} size={70}/></button><h2>{selected.name}</h2><span className="details-role">{selected.role}</span><span className="details-presence">{selected.kind==='direct'?<i className={selected.online?'online':'offline'}/>:<UsersRound size={13}/>} {selected.kind==='direct'?selected.online?'Active now':selected.status:`${selected.members?.length||0} members`}</span><div className="details-shortcuts"><button onClick={()=>openProfile()}><span><UserRound size={17}/></span>Profile</button><button onClick={()=>{setSearchTerm('');setOverlay('search');}}><span><Search size={17}/></span>Search</button><button onClick={toggleMute}><span>{muted.includes(selected.id)?<VolumeX size={17}/>:<Bell size={17}/>}</span>{muted.includes(selected.id)?'Muted':'Mute'}</button></div></div>
      <div className="details-rule"/>
      {selected.kind==='group'&&<div className="details-section group-members-section"><div className="section-heading"><h3>Members <span>{selected.members?.length}</span></h3><button onClick={()=>setOverlay('manage')}>Manage <ChevronRight size={15}/></button></div><div className="member-preview">{selected.members?.slice(0,4).map(person=><div className="member-preview-row" key={person.name}><Avatar src={person.avatar} name={person.name} size={30}/><strong>{person.name==='Tadjodong Liano Herman'?'You':person.name}</strong>{person.role!=='Member'&&<span>{person.role}</span>}</div>)}</div></div>}
      <div className="ai-card"><div className="ai-card-heading"><span className="ai-symbol"><Sparkles size={17} fill="currentColor"/></span><strong>HChat AI</strong><span className="beta-pill">BETA</span></div><h3>Good conversations.<br/><em>Even better clarity.</em></h3><p>Pick up where you left off, find the right words, and keep things moving.</p><div className="ai-quick-grid"><button onClick={()=>void openAI('summary')}><span><MessageSquare size={16}/></span>Summarize</button><button onClick={()=>void openAI('suggest')}><span><Sparkles size={16}/></span>Suggest reply</button><button onClick={()=>{const last=[...selectedMessages].reverse().find(x=>x.sender==='other'&&x.text);void openAI('translate',last?.text||'');}}><span><Languages size={16}/></span>Translate</button><button onClick={openReminder}><span><Clock3 size={16}/></span>Remind me</button></div></div>
      <div className="details-section"><div className="section-heading"><h3>Shared media</h3><button onClick={()=>{if(sharedMedia.length)openMedia(sharedMedia[0]);else notify('No media shared in this conversation yet.');}}>See all <ChevronRight size={15}/></button></div>{sharedMedia.length?<div className="media-grid">{sharedMedia.slice(0,3).map((media,i)=><button key={`${media.url}-${i}`} onClick={()=>openMedia(media)} title={media.name}><img src={media.url} alt={media.name} loading="lazy"/></button>)}</div>:<div className="section-empty">Images you share will appear here.</div>}</div>
      <div className="details-section shared-files-section"><div className="section-heading"><h3>Shared files</h3>{sharedFiles.length>1&&<span>{sharedFiles.length}</span>}</div>{sharedFiles.length?sharedFiles.slice(0,2).map((file,i)=><a className="shared-file-row" key={i} href={file.url} target="_blank" rel="noreferrer"><span className="shared-file-icon"><FileText size={18}/></span><span><strong>{file.name}</strong><small>{file.size} · Document</small></span><Download size={16}/></a>):<div className="section-empty">Nothing shared just yet.</div>}</div>
      {selected.kind==='direct'&&<div className="details-section mutual-section"><div className="section-heading"><h3>Groups in common</h3></div><div className="mutual-group">{selected.mutualGroups?.map((group,i)=><button key={group} onClick={()=>{const conv=conversations.find(x=>x.name===group);if(conv)pickConversation(conv.id);else notify('Group not found.');}}><span className={`mutual-icon mutual-${i}`}><UsersRound size={15}/></span>{group}<ChevronRight size={14}/></button>)}</div></div>}
    </div></aside>}
  </div>
  <AnimatePresence>{overlay&&renderOverlay()}</AnimatePresence>
  <AnimatePresence>{toast&&<motion.div className="toast" role="status" initial={{opacity:0,y:16,scale:.96}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:8,scale:.97}}><span className="toast-check"><Check size={14}/></span>{toast}<button aria-label="Dismiss notification" onClick={()=>setToast('')}><X size={14}/></button></motion.div>}</AnimatePresence>
</div>;

  function renderOverlay():ReactNode {
    if(overlay==='search')return <Modal key="search" label="Search HChat" className="search-modal" onClose={()=>setOverlay(null)}><div className="search-modal-input"><Search size={21}/><input autoFocus value={searchTerm} onChange={e=>setSearchTerm(e.target.value)} placeholder="Search messages, files, links, people..." aria-label="Search query"/><kbd>ESC</kbd></div><div className="search-modal-tabs">{(['All','Messages','People','Files','Links'] as SearchTab[]).map(tab=><button className={searchTab===tab?'active':''} key={tab} onClick={()=>setSearchTab(tab)}>{tab}</button>)}</div><div className="search-content">
      {!searchTerm&&<div className="search-suggestion-row"><span>TRENDING SEARCHES</span>{['launch','moodboard','assets'].map(term=><button key={term} onClick={()=>setSearchTerm(term)}><Search size={13}/>{term}</button>)}</div>}
      {searchCount===0?<div className="search-empty"><Search size={29}/><h3>No matches found</h3><p>Try another keyword or search across all conversations.</p></div>:<>
        {(searchTab==='All'||searchTab==='People')&&searchResults.people.length>0&&<div className="search-section"><h4>PEOPLE & CONVERSATIONS <span>{searchResults.people.length}</span></h4>{searchResults.people.map(person=><button className="search-result" key={person.id} onClick={()=>pickConversation(person.id)}><ConversationAvatar conversation={person} size={37}/><span><strong><Highlight text={person.name} query={searchTerm}/></strong><small>{person.role}</small></span><ArrowUpRight size={16}/></button>)}</div>}
        {(searchTab==='All'||searchTab==='Messages')&&searchResults.messages.length>0&&<div className="search-section"><h4>MESSAGES <span>{searchResults.messages.length}</span></h4>{searchResults.messages.map(message=><button className="search-result" key={message.id} onClick={()=>{setTargetMessageId(message.id);pickConversation(message.conversationId);}}><span className="search-result-icon"><MessageSquare size={16}/></span><span><strong>{conversations.find(x=>x.id===message.conversationId)?.name||'Conversation'}</strong><small><Highlight text={message.text} query={searchTerm}/></small></span><span className="search-result-time">{message.time}</span></button>)}</div>}
        {(searchTab==='All'||searchTab==='Files')&&searchResults.files.length>0&&<div className="search-section"><h4>FILES <span>{searchResults.files.length}</span></h4>{searchResults.files.map(message=><button className="search-result" key={message.id} onClick={()=>{const file=message.attachment!;if(file.kind==='image')openMedia(file);else window.open(file.url,'_blank','noopener,noreferrer');}}><span className="search-result-icon"><FileText size={16}/></span><span><strong><Highlight text={message.attachment!.name} query={searchTerm}/></strong><small>Shared in {conversations.find(x=>x.id===message.conversationId)?.name} · {message.attachment!.size}</small></span><ArrowUpRight size={16}/></button>)}</div>}
        {(searchTab==='All'||searchTab==='Links')&&searchResults.links.length>0&&<div className="search-section"><h4>LINKS <span>{searchResults.links.length}</span></h4>{searchResults.links.map(message=><button className="search-result" key={message.id} onClick={()=>{setTargetMessageId(message.id);pickConversation(message.conversationId);}}><span className="search-result-icon"><Link2 size={16}/></span><span><strong>{conversations.find(x=>x.id===message.conversationId)?.name}</strong><small><Highlight text={message.text} query={searchTerm}/></small></span><ArrowUpRight size={16}/></button>)}</div>}
        {searchTerm&&((searchTab==='Messages'&&!searchResults.messages.length)||(searchTab==='People'&&!searchResults.people.length)||(searchTab==='Files'&&!searchResults.files.length)||(searchTab==='Links'&&!searchResults.links.length))&&<div className="search-empty compact"><Search size={24}/><h3>Nothing in {searchTab.toLowerCase()} yet</h3><p>Try another keyword.</p></div>}
      </>}
    </div><div className="search-modal-footer"><span><kbd>↵</kbd> Open result</span><span><kbd>ESC</kbd> Close</span><span>Search across your HChat workspace</span></div></Modal>;
    if(overlay==='new')return <Modal key="new" label="New conversation" className="new-modal" onClose={()=>setOverlay(null)}><ModalHeading icon={<Plus size={20}/>} title="New conversation" subtitle="Good things start with a hello." onClose={()=>setOverlay(null)}/><div className="new-tabs"><button className={newTab==='message'?'active':''} onClick={()=>setNewTab('message')}><MessageSquare size={16}/> Direct message</button><button className={newTab==='group'?'active':''} onClick={()=>setNewTab('group')}><UsersRound size={16}/> New group</button></div>{newTab==='group'&&<div className="form-field group-name-field"><label htmlFor="group-name">GROUP NAME</label><input id="group-name" value={newGroupName} onChange={e=>setNewGroupName(e.target.value)} placeholder="e.g. Product launch" maxLength={90}/></div>}<div className="new-list-head"><span>{newTab==='group'?'ADD PEOPLE':'START A CONVERSATION'}</span><small>{newTab==='group'?`${groupPeople.length} selected`:`${contacts.length} people`}</small></div><div className="new-people-list">{newPeople.map(person=><button key={person.id} className="new-person" onClick={()=>{if(newTab==='message')pickConversation(person.id);else setGroupPeople(prev=>prev.includes(person.id)?prev.filter(x=>x!==person.id):[...prev,person.id]);}}><Avatar src={person.avatar} name={person.name} size={39} online={person.online}/><span><strong>{person.name}</strong><small>{person.role}</small></span>{newTab==='group'&&<span className={`select-check ${groupPeople.includes(person.id)?'checked':''}`}>{groupPeople.includes(person.id)&&<Check size={13}/>}</span>}</button>)}</div>{newTab==='group'&&<div className="new-modal-footer"><span>{groupPeople.length<2?'Select at least 2 people to create a group.':`${groupPeople.length} people selected`}</span><button className="primary-button" disabled={groupPeople.length<2||!newGroupName.trim()} onClick={async()=>{const members:Member[]=contacts.filter(x=>groupPeople.includes(x.id)).map(x=>({name:x.name,avatar:x.avatar,role:'Member'}));try{const item=await request<Conversation>('/api/conversations',jsonPost({name:newGroupName.trim(),kind:'group',members}));setConversations(prev=>prev.some(x=>x.id===item.id)?prev:[item,...prev]);setNewGroupName('');setGroupPeople([]);pickConversation(item.id);notify('Group created successfully.');}catch(error){notify(error instanceof Error?error.message:'Could not create group.');}}}>Create group <ArrowRight size={16}/></button></div>}</Modal>;

    if(overlay==='profile'){
      const profile=profileTarget==='me'?null:conversations.find(x=>x.id===profileTarget)||selected;
      const own=profileTarget==='me';
      const name=own?displayName:profile?.name||'';
      return <Modal key="profile" label={`${name} profile`} className="profile-modal" onClose={()=>setOverlay(null)}><div className="profile-cover"><div className="profile-cover-glow"/><div className="profile-cover-pattern"/><button className="icon-btn profile-close" aria-label="Close profile" onClick={()=>setOverlay(null)}><X size={18}/></button><div className="profile-avatar-big">{own?<Avatar src={session?.user?.image||'/avatars/herman.jpg'} name={name} size={86} online/>:profile&&<ConversationAvatar conversation={profile} size={86}/>}</div></div><div className="profile-body"><div className="profile-status-row"><h2>{name}</h2><span className="profile-presence"><i className={own||profile?.online?'online':'offline'}/>{own?'Available':profile?.kind==='group'?`${profile.members?.length||0} members`:profile?.status}</span></div><p className="profile-role">{own?'Founder & creator of HChat':profile?.role}</p><div className="profile-divider"/><div className="profile-block"><span className="block-label">ABOUT</span><p>{own?prefs.bio:profile?.bio}</p></div>{!own&&profile?.kind==='direct'&&<><div className="profile-block"><span className="block-label">GROUPS IN COMMON</span><div className="profile-tags">{profile.mutualGroups?.map(group=><button key={group} onClick={()=>{const found=conversations.find(x=>x.name===group);if(found)pickConversation(found.id);}}><UsersRound size={14}/>{group}</button>)}</div></div><div className="profile-block"><span className="block-label">SHARED IN THIS CONVERSATION</span><div className="profile-media">{messages.filter(x=>x.conversationId===profile.id&&x.attachment?.kind==='image').map(x=><button key={x.id} onClick={()=>openMedia(x.attachment!)}><img src={x.attachment!.url} alt={x.attachment!.name}/></button>)}{profile.id==='maya'&&['/media/brand-exploration.svg','/media/interface-study.svg'].map(url=><button key={url} onClick={()=>openMedia({kind:'image',url,name:url.split('/').pop()||'Media',size:'1.8 MB'})}><img src={url} alt="Shared media"/></button>)}</div></div></>}{!own&&profile?.kind==='group'&&<div className="profile-block"><span className="block-label">MEMBERS · {profile.members?.length}</span>{profile.members?.slice(0,4).map(person=><div className="profile-member" key={person.name}><Avatar src={person.avatar} name={person.name} size={32}/><strong>{person.name}</strong><small>{person.role}</small></div>)}</div>}{own&&<div className="profile-block"><span className="block-label">ABOUT HCHAT</span><p>Simple. Fast. Intelligent. A more thoughtful way to connect and collaborate.</p><span className="creator-note">Designed and built by Tadjodong Liano Herman.</span></div>}<div className="profile-actions">{own?<button className="primary-button" onClick={()=>{setSettingsTab('Account');setOverlay('settings');}}>Edit profile <ArrowRight size={16}/></button>:<button className="primary-button" onClick={()=>pickConversation(profile!.id)}><MessageSquare size={16}/> Open conversation</button>}{!own&&<button className="secondary-button" onClick={()=>{void navigator.clipboard?.writeText(`${window.location.origin}/?conversation=${profile!.id}`);notify('Conversation link copied.');}}><Copy size={16}/> Copy link</button>}</div></div></Modal>;
    }
    if(overlay==='media'&&selectedMedia)return <Modal key="media" label="Shared media viewer" className="media-modal" onClose={()=>setOverlay(null)}><div className="media-viewer-head"><span><ImageIcon size={18}/>{selectedMedia.name}</span><div><a href={selectedMedia.url} download={selectedMedia.name} className="icon-btn" aria-label="Download media" title="Download"><Download size={18}/></a><button className="icon-btn" onClick={()=>setOverlay(null)} aria-label="Close"><X size={18}/></button></div></div><div className="media-viewer-body">{mediaGallery.length>1&&<button className="media-gallery-arrow" aria-label="Previous image" onClick={()=>setSelectedMedia(mediaGallery[(mediaGallery.findIndex(x=>x.url===selectedMedia.url)-1+mediaGallery.length)%mediaGallery.length])}><ArrowLeft size={20}/></button>}<img src={selectedMedia.url} alt={selectedMedia.name}/>{mediaGallery.length>1&&<button className="media-gallery-arrow" aria-label="Next image" onClick={()=>setSelectedMedia(mediaGallery[(mediaGallery.findIndex(x=>x.url===selectedMedia.url)+1)%mediaGallery.length])}><ArrowRight size={20}/></button>}</div><div className="media-viewer-footer"><span>Shared in {selected?.name}</span>{mediaGallery.length>1&&<div className="media-gallery-dots">{mediaGallery.map((item,i)=><button key={`${item.url}-${i}`} className={selectedMedia.url===item.url?"active":""} aria-label={`View image ${i+1}`} onClick={()=>setSelectedMedia(item)}/>)}</div>}<span>{selectedMedia.size}</span></div></Modal>;

    if(overlay==='ai')return <Modal key="ai" label="HChat AI assistant" className="ai-modal" onClose={()=>setOverlay(null)}><div className="ai-modal-glow"/><ModalHeading icon={<Sparkles size={20}/>} title="HChat AI" subtitle="A little more clarity, right when you need it." onClose={()=>setOverlay(null)}/><div className="ai-modal-tabs"><button className={aiAction==='summary'?'active':''} onClick={()=>void openAI('summary')}><MessageSquare size={15}/> Summary</button><button className={aiAction==='suggest'?'active':''} onClick={()=>void openAI('suggest')}><Sparkles size={15}/> Replies</button><button className={aiAction==='translate'?'active':''} onClick={()=>{const last=[...selectedMessages].reverse().find(x=>x.sender==='other'&&x.text);void openAI('translate',last?.text||'');}}><Languages size={15}/> Translate</button></div><div className="ai-context-line"><ConversationAvatar conversation={selected} size={27}/><span>In conversation with <strong>{selected.name}</strong></span><span className="ai-private-badge"><ShieldCheck size={12}/> Private</span></div>{aiAction==='translate'&&<div className="ai-translate-controls"><label htmlFor="target-language">Translate to</label><select id="target-language" value={translateTarget} onChange={e=>void openAI('translate',aiSourceText||[...selectedMessages].reverse().find(x=>x.sender==='other'&&x.text)?.text||'',e.target.value)}><option>French</option><option>Spanish</option><option>English</option></select></div>}
      <div className="ai-result-card"><div className="ai-result-label"><Sparkles size={14}/>{aiAction==='summary'?'CONVERSATION SUMMARY':aiAction==='suggest'?'SUGGESTED REPLIES':'TRANSLATION'}</div>{aiLoading?<div className="ai-loading"><div/><div/><div/></div>:<>{aiAction==='suggest'&&aiReplies.length?<div className="ai-reply-options">{aiReplies.map((reply,i)=><button key={i} onClick={()=>{setDraft(reply);setOverlay(null);setTimeout(()=>inputRef.current?.focus(),100);notify('Reply added to your message.');}}><span>{reply}</span><ArrowUpRight size={16}/></button>)}</div>:<p>{aiText}</p>}</>}</div><div className="ai-modal-bottom"><span>{aiMode==='demo'?'Smart preview response · Add an AI key for open-ended intelligence':aiMode==='unavailable'?'Add OPENAI_API_KEY for open-ended translation':aiMode==='AI'?'Powered by HChat AI':'Thoughtful help, on demand'}</span>{aiAction==='translate'&&aiText&&aiMode!=='unavailable'&&<button onClick={()=>{void navigator.clipboard?.writeText(aiText);notify('Translation copied.');}}><Copy size={15}/> Copy</button>}</div></Modal>;

    if(overlay==='reminder')return <Modal key="reminder" label="Create reminder" className="reminder-modal" onClose={()=>setOverlay(null)}><ModalHeading icon={<Clock3 size={20}/>} title="Set a reminder" subtitle="We'll help you pick up the thread later." onClose={()=>setOverlay(null)}/><form onSubmit={e=>void createReminder(e)} className="standard-form"><div className="form-field"><label htmlFor="reminder-name">REMIND ME TO</label><textarea id="reminder-name" value={reminderText} onChange={e=>setReminderText(e.target.value)} rows={2} maxLength={500} placeholder="Follow up on the project" required/></div><div className="form-field"><label htmlFor="reminder-time">WHEN</label><select id="reminder-time" value={reminderWhen} onChange={e=>setReminderWhen(e.target.value)}><option>Later today</option><option>Tomorrow morning</option><option>Next week</option><option>Pick a date</option></select></div>{reminderWhen==='Pick a date'&&<div className="form-field"><label htmlFor="custom-time">DATE & TIME</label><input id="custom-time" type="datetime-local" value={reminderCustom} onChange={e=>setReminderCustom(e.target.value)} required/></div>}<div className="reminder-context"><MessageSquare size={16}/> In your conversation with <strong>{selected.name}</strong></div><div className="modal-form-actions"><button type="button" className="secondary-button" onClick={()=>setOverlay(null)}>Cancel</button><button className="primary-button" type="submit"><Clock3 size={16}/> Create reminder</button></div></form></Modal>;

    if(overlay==='poll')return <Modal key="poll" label="Create group poll" className="poll-modal" onClose={()=>setOverlay(null)}><ModalHeading icon={<ListFilter size={20}/>} title="Create a poll" subtitle={`Ask the ${selected.name} group what they think.`} onClose={()=>setOverlay(null)}/><form className="standard-form" onSubmit={e=>void createPoll(e)}><div className="form-field"><label htmlFor="poll-question">QUESTION</label><input id="poll-question" placeholder="What should we decide together?" value={pollQuestion} onChange={e=>setPollQuestion(e.target.value)} maxLength={180} required/></div><div className="form-field"><label>OPTIONS</label>{pollOptions.map((option,i)=><div className="poll-input-row" key={i}><input aria-label={`Option ${i+1}`} value={option} onChange={e=>setPollOptions(prev=>prev.map((item,j)=>j===i?e.target.value:item))} placeholder={`Option ${i+1}`} maxLength={100}/>{pollOptions.length>2&&<button type="button" title="Remove option" onClick={()=>setPollOptions(prev=>prev.filter((_,j)=>j!==i))}><X size={17}/></button>}</div>)}{pollOptions.length<6&&<button type="button" className="add-option" onClick={()=>setPollOptions(prev=>[...prev,''])}><Plus size={16}/> Add an option</button>}</div><div className="modal-form-actions"><button type="button" className="secondary-button" onClick={()=>setOverlay(null)}>Cancel</button><button type="submit" className="primary-button"><Send size={15}/> Share poll</button></div></form></Modal>;

    if(overlay==='notifications')return <Modal key="notifications" label="Notifications" className="notifications-modal" onClose={()=>setOverlay(null)}><ModalHeading icon={<Bell size={20}/>} title="Notifications" subtitle="A pulse on what’s happening." onClose={()=>setOverlay(null)}/><div className="notifications-top"><span>{notificationTotal} unread</span><button onClick={()=>{setNotifications(prev=>prev.map(x=>({...x,unread:false})));notify('All notifications marked as read.');}}><CheckCheck size={15}/> Mark all read</button></div><div className="notification-list">{reminders.length>0&&<div className="notification-group"><span className="block-label">YOUR REMINDERS</span>{reminders.map(item=><button key={item.id} className="notification-item" onClick={()=>pickConversation(item.conversationId)}><span className="notification-reminder-icon"><Clock3 size={19}/></span><span><strong>Reminder</strong><span>{item.text}</span><small>{new Date(item.dueAt).toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}</small></span></button>)}</div>}<div className="notification-group"><span className="block-label">RECENT</span>{notifications.map(item=><button className={`notification-item ${item.unread?'unread':''}`} key={item.id} onClick={()=>{setNotifications(prev=>prev.map(x=>x.id===item.id?{...x,unread:false}:x));pickConversation(item.conversationId);}}><Avatar src={item.avatar} name={item.title} size={38}/><span><strong>{item.title}</strong><span>{item.detail}</span><small>{item.time}</small></span>{item.unread&&<i/>}</button>)}</div></div><div className="notifications-footer"><Bell size={14}/> You’re up to date with your conversations.</div></Modal>;

    if(overlay==='manage')return <Modal key="manage" label="Manage group members" className="manage-modal" onClose={()=>setOverlay(null)}><ModalHeading icon={<UsersRound size={20}/>} title="Group members" subtitle={`Manage the people in ${selected.name}.`} onClose={()=>setOverlay(null)}/><div className="manage-list"><div className="block-label">MEMBERS · {selected.members?.length||0}</div>{selected.members?.map(member=><div className="manage-member" key={member.name}><Avatar src={member.avatar} name={member.name} size={40}/><span><strong>{member.name==='Tadjodong Liano Herman'?'You':member.name}</strong><small>{member.role}</small></span>{member.role==='Owner'?<span className="owner-badge">Owner</span>:<><select aria-label={`Role for ${member.name}`} value={member.role} onChange={async e=>{const members=selected.members!.map(x=>x.name===member.name?{...x,role:e.target.value as Member['role']}:x);try{const item=await request<Conversation>(`/api/conversations/${selected.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({members})});setConversations(prev=>prev.map(x=>x.id===item.id?item:x));notify(`${member.name} is now ${e.target.value.toLowerCase()}.`);}catch{notify('Could not update role.');}}}><option>Admin</option><option>Member</option></select><button title={`Remove ${member.name}`} aria-label={`Remove ${member.name}`} onClick={async()=>{const members=selected.members!.filter(x=>x.name!==member.name);try{const item=await request<Conversation>(`/api/conversations/${selected.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({members})});setConversations(prev=>prev.map(x=>x.id===item.id?item:x));notify(`${member.name} removed from the group.`);}catch{notify('Could not remove member.');}}}><Trash2 size={17}/></button></>}</div>)}</div><div className="manage-add"><div className="block-label">ADD SOMEONE</div><div className="manage-add-grid">{contacts.filter(x=>!selected.members?.some(m=>m.name===x.name)).map(person=><button key={person.id} onClick={async()=>{const members=[...(selected.members||[]),{name:person.name,avatar:person.avatar,role:'Member' as const}];try{const item=await request<Conversation>(`/api/conversations/${selected.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({members})});setConversations(prev=>prev.map(x=>x.id===item.id?item:x));notify(`${person.name} added to ${selected.name}.`);}catch{notify('Could not add member.');}}}><Avatar src={person.avatar} name={person.name} size={31}/>{person.name}<Plus size={16}/></button>)}</div></div></Modal>;

    if(overlay==='settings')return <Modal key="settings" label="HChat settings" className="settings-modal" onClose={()=>setOverlay(null)}><div className="settings-navigation"><div className="settings-brand"><BrandMark size={32}/><span>Settings</span></div><div className="settings-navigation-label">PREFERENCES</div>{(['Account','Security','Appearance','Notifications','Privacy','Language'] as SettingsTab[]).map((tab)=>{const icons:{[key in SettingsTab]:ReactNode}={Account:<UserRound size={17}/>,Security:<ShieldCheck size={17}/>,Appearance:<Moon size={17}/>,Notifications:<Bell size={17}/>,Privacy:<ShieldCheck size={17}/>,Language:<Languages size={17}/>};return <button key={tab} className={settingsTab===tab?'active':''} onClick={()=>setSettingsTab(tab)}>{icons[tab]}{tab}<ChevronRight size={15}/></button>})}<div className="settings-nav-footer">HChat v1.0<br/>Simple. Fast. Intelligent.</div></div><div className="settings-content"><div className="settings-content-head"><div><span className="eyebrow">HCHAT / SETTINGS</span><h2>{settingsTab}</h2><p>{({Account:'The little details that make it yours.',Security:'Keep your account and data in good hands.',Appearance:'Make HChat feel right for you.',Notifications:'Stay in the loop, on your terms.',Privacy:'Your conversations, your choices.',Language:'Feel at home in your conversations.'} as Record<SettingsTab,string>)[settingsTab]}</p></div><button className="icon-btn" aria-label="Close settings" onClick={()=>setOverlay(null)}><X size={19}/></button></div><div className="settings-pane">
      {settingsTab==='Account'&&<><div className="settings-account-header"><Avatar src={session?.user?.image||'/avatars/herman.jpg'} name={displayName} size={62} online/><div><strong>{displayName}</strong><span>{session?.user?.email||'Your HChat profile'}</span></div><span className="account-verified"><CheckCircle2 size={14}/> Active</span></div><div className="settings-divider"/><div className="form-field"><label htmlFor="settings-name">DISPLAY NAME</label><input id="settings-name" value={prefs.displayName} onChange={e=>setPrefs(p=>({...p,displayName:e.target.value}))}/></div><div className="form-field"><label htmlFor="settings-bio">BIO</label><textarea id="settings-bio" value={prefs.bio} rows={3} onChange={e=>setPrefs(p=>({...p,bio:e.target.value}))} maxLength={200}/><small>Let people know a little about you.</small></div><button className="primary-button settings-save" onClick={()=>notify('Profile saved to this device.')}><Check size={16}/> Save changes</button></>}
      {settingsTab==='Security'&&<><div className="settings-panel-title"><ShieldCheck size={19}/><div><strong>Password & sign-in</strong><span>Take care of your account access.</span></div></div><div className="settings-setting-row"><div><strong>Password</strong><span>Use a strong, unique password for HChat.</span></div><button onClick={()=>window.location.href='/login?recover=1'}>Reset password <ArrowUpRight size={15}/></button></div><div className="settings-setting-row"><div><strong>Current session</strong><span>This browser · Active now</span></div><span className="secure-pill"><i/> Active</span></div><div className="settings-note"><ShieldCheck size={19}/><span>Credentials are securely hashed, and your sign-in session is managed by Auth.js.</span></div><button className="settings-signout" onClick={()=>{if(session)void signOut({redirectTo:'/login'});else window.location.href='/login';}}><LogOut size={16}/> {session?'Sign out of HChat':'Go to sign in'}</button></>}
      {settingsTab==='Appearance'&&<><div className="block-label">THEME</div><div className="theme-options"><button className={prefs.theme==='dark'?'selected':''} onClick={()=>setPrefs(p=>({...p,theme:'dark'}))}><div className="theme-preview dark-preview"><span/><span/><i/></div><strong><Moon size={16}/> Midnight</strong><small>Easy on the eyes</small>{prefs.theme==='dark'&&<CheckCircle2 size={18} className="theme-check"/>}</button><button className={prefs.theme==='light'?'selected':''} onClick={()=>setPrefs(p=>({...p,theme:'light'}))}><div className="theme-preview light-preview"><span/><span/><i/></div><strong><span className="sun-symbol">☀</span> Daylight</strong><small>A breath of fresh air</small>{prefs.theme==='light'&&<CheckCircle2 size={18} className="theme-check"/>}</button></div><div className="settings-divider"/><div className="block-label">ACCENT COLOR</div><div className="accent-options"><button className={prefs.accent==='blue'?'selected':''} onClick={()=>setPrefs(p=>({...p,accent:'blue'}))}><i className="blue-swatch"/> Electric blue {prefs.accent==='blue'&&<Check size={16}/>}</button><button className={prefs.accent==='violet'?'selected':''} onClick={()=>setPrefs(p=>({...p,accent:'violet'}))}><i className="violet-swatch"/> Violet {prefs.accent==='violet'&&<Check size={16}/>}</button></div></>}
      {settingsTab==='Notifications'&&<><div className="settings-panel-title"><Bell size={19}/><div><strong>Stay in the know</strong><span>Only the updates you care about.</span></div></div><div className="settings-setting-row"><div><strong>Browser notifications</strong><span>Get alerts while HChat is open.</span></div><button role="switch" aria-checked={prefs.desktopNotifications} className={`toggle ${prefs.desktopNotifications?'on':''}`} onClick={async()=>{if(!prefs.desktopNotifications&&'Notification' in window){const permission=await window.Notification.requestPermission();if(permission==='denied')notify('Browser notifications are blocked in your browser.');}setPrefs(p=>({...p,desktopNotifications:!p.desktopNotifications}));}}><span/></button></div><div className="settings-setting-row"><div><strong>Notification sounds</strong><span>A subtle sound for new messages.</span></div><button role="switch" aria-checked={prefs.sound} className={`toggle ${prefs.sound?'on':''}`} onClick={()=>setPrefs(p=>({...p,sound:!p.sound}))}><span/></button></div><div className="settings-note"><Bell size={17}/><span>Mute individual conversations from their details panel.</span></div></>}
      {settingsTab==='Privacy'&&<><div className="settings-panel-title"><ShieldCheck size={19}/><div><strong>Your space, your rules</strong><span>Choose what others can see.</span></div></div><div className="settings-setting-row"><div><strong>Read receipts</strong><span>Let others know when you’ve seen a message.</span></div><button role="switch" aria-checked={prefs.readReceipts} className={`toggle ${prefs.readReceipts?'on':''}`} onClick={()=>setPrefs(p=>({...p,readReceipts:!p.readReceipts}))}><span/></button></div><div className="settings-note"><ShieldCheck size={17}/><span>This preference is saved locally for the demo workspace. Production privacy controls require account-level policy enforcement.</span></div></>}
      {settingsTab==='Language'&&<><div className="settings-panel-title"><Languages size={19}/><div><strong>Display language</strong><span>Choose your preferred language.</span></div></div><div className="language-choices">{['English','Français','Español'].map(language=><button className={prefs.language===language?'selected':''} key={language} onClick={()=>{setPrefs(p=>({...p,language}));notify('Language preference saved. The demo interface is currently in English.');}}><span><strong>{language}</strong><small>{language==='English'?'English':language==='Français'?'French':'Spanish'}</small></span>{prefs.language===language&&<CheckCircle2 size={18}/>}</button>)}</div><div className="settings-note"><Languages size={17}/><span>Translation in conversations is available with HChat AI. The preview interface currently uses English.</span></div></>}
    </div><div className="settings-content-footer">Made with care by Tadjodong Liano Herman <span>✦</span></div></div></Modal>;
    return null;
  }
}
