'use client';
import { AnimatePresence, motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useEffect, useRef, type ReactNode } from 'react';
import type { Conversation } from '@/lib/types';

export function BrandMark({ size = 36, className = '' }: { size?: number; className?: string }) {
  return <span className={`brand-mark ${className}`} style={{ width: size, height: size }} aria-hidden="true"><svg width={size * .57} height={size * .57} viewBox="0 0 24 24" fill="none"><path d="M5.6 5.5v13M18.4 5.5v13M5.6 12h12.8" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg></span>;
}
export function Wordmark({ compact = false }: { compact?: boolean }) {
  return <div className="wordmark"><BrandMark size={compact ? 34 : 39}/><span>hchat<span className="wordmark-dot">.</span></span></div>;
}
export function Avatar({ src, name, size = 42, online = false, className = '' }: { src?: string; name: string; size?: number; online?: boolean; className?: string }) {
  return <span className={`avatar-wrap ${className}`} style={{ width: size, height: size, minWidth: size }}><span className="avatar-core" style={{width:size,height:size}}>{src ? <img src={src} alt={name} draggable="false"/> : <span className="avatar-initial">{name.split(' ').map(x => x[0]).slice(0,2).join('').toUpperCase()}</span>}</span>{online && <span className="online-dot" role="img" aria-label="Online"/>}</span>;
}
export function GroupAvatar({ conversation, size = 46 }: { conversation: Conversation; size?: number }) {
  const people = conversation.members?.filter(x => x.role !== 'Owner').slice(0,3) || [];
  return <span className="group-avatar" style={{width:size,height:size,minWidth:size}} aria-label={`${conversation.name} group avatar`}>
    {people.length ? people.map((person, i) => <img key={person.name} src={person.avatar} alt="" style={{ transform: `translate(${i === 0 ? -size*.15 : i === 1 ? size*.17 : size*.01}px, ${i === 2 ? size*.22 : -size*.11}px)`, zIndex: i + 1, width:size*.52, height:size*.52 }}/>) : <span className="group-initial">{conversation.name.slice(0,1)}</span>}
  </span>;
}
export function ConversationAvatar({ conversation, size = 44 }: { conversation: Conversation; size?: number }) {
  return conversation.kind === 'group' ? <GroupAvatar conversation={conversation} size={size}/> : <Avatar src={conversation.avatar} name={conversation.name} size={size} online={conversation.online}/>;
}
export function Modal({ children, onClose, className = '', label }: { children: ReactNode; onClose: () => void; className?: string; label: string }) {
  const dialogRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    if (!dialogRef.current?.contains(document.activeElement)) dialogRef.current?.focus();
    const trap = (event: KeyboardEvent) => {
      if (event.key !== 'Tab' || !dialogRef.current) return;
      const focusable = Array.from(dialogRef.current.querySelectorAll<HTMLElement>('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')).filter(element => element.getClientRects().length);
      if (!focusable.length) { event.preventDefault(); return; }
      if (event.shiftKey && document.activeElement === focusable[0]) { event.preventDefault(); focusable.at(-1)?.focus(); }
      else if (!event.shiftKey && document.activeElement === focusable.at(-1)) { event.preventDefault(); focusable[0].focus(); }
    };
    document.addEventListener('keydown', trap);
    return () => { document.removeEventListener('keydown', trap); previous?.focus(); };
  }, []);
  return <motion.div className="modal-backdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} transition={{duration:.18}} onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <motion.div ref={dialogRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label={label} className={`modal-shell ${className}`} initial={{opacity:0,scale:.965,y:14}} animate={{opacity:1,scale:1,y:0}} exit={{opacity:0,scale:.97,y:8}} transition={{type:'spring', stiffness:390,damping:32}}>{children}</motion.div>
  </motion.div>;
}
export function ModalHeading({ icon, title, subtitle, onClose }: { icon?: ReactNode; title: string; subtitle?: string; onClose: () => void }) {
  return <div className="modal-heading"><div className="modal-heading-title">{icon && <span className="modal-heading-icon">{icon}</span>}<div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div></div><button className="icon-btn modal-close" onClick={onClose} aria-label="Close"><X size={18}/></button></div>;
}
export function Presence({ children }: { children: ReactNode }) { return <AnimatePresence mode="wait">{children}</AnimatePresence>; }
